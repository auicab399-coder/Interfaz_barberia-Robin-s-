<?php
include("conexion/db.php");

// 1. Obtener los datos del propietario
$sql_usuario = "SELECT nombre FROM usuarios WHERE id_usuario = 1";
$datos_usuario = $conexion->query($sql_usuario)->fetch_assoc();

// 2. Obtener el historial de ventas registradas con sus detalles agrupados
// GROUP_CONCAT agrupa los servicios y productos asociados a un mismo folio en una sola celda
$sql_ventas = "
    SELECT v.folio_venta, v.fecha_hora, c.nombre as cliente, v.metodo_pago, v.descuento_monto, v.total_venta,
        (SELECT GROUP_CONCAT(CONCAT(s.nombre, ' ×', dvs.cantidad) SEPARATOR '<br>') 
         FROM detalle_venta_servicio dvs 
         INNER JOIN servicios s ON dvs.id_servicio = s.id_servicio 
         WHERE dvs.folio_venta = v.folio_venta) as servicios_detalle,
        (SELECT GROUP_CONCAT(CONCAT(p.nombre, ' ×', dvp.cantidad) SEPARATOR '<br>') 
         FROM detalle_venta_producto dvp 
         INNER JOIN productos p ON dvp.id_producto = p.id_producto 
         WHERE dvp.folio_venta = v.folio_venta) as productos_detalle
    FROM ventas v
    LEFT JOIN clientes c ON v.id_cliente = c.id_cliente
    WHERE v.estado = 'completada'
    ORDER BY v.fecha_hora DESC";
$resultado_ventas = $conexion->query($sql_ventas);

// 3. Obtener el catálogo de servicios para las tarjetas (excluyendo la penalización S09)
$sql_servicios = "SELECT id_servicio, nombre, categoria, descripcion, duracion_min, precio 
                  FROM servicios 
                  WHERE id_servicio != 's09' AND estado = 'activo'
                  ORDER BY id_servicio ASC";
$resultado_servicios = $conexion->query($sql_servicios);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas · Barbería Robin's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
</head>
<body class="pag-ventas">

    <div class="app">

        <div id="menu-root"></div>

        <main class="app-contenido">

            <header class="encabezado">
                <div class="titulo">
                    <h1>Ventas</h1>
                    <p>Ventas registradas y catálogo de servicios</p>
                </div>
                <div class="encabezado-derecha">
                    <button class="btn-agregar btn-nueva-venta" type="button" data-nueva-venta><span aria-hidden="true">＋</span> Nueva venta</button>
                    <div class="usuario">
                        <span class="usuario-icono">LH</span>
                        <div class="usuario-datos">
                            <strong><?= htmlspecialchars($datos_usuario['nombre']) ?></strong>
                            <small>Propietario</small>
                        </div>
                    </div>
                </div>
            </header>

            <nav class="pestanas" aria-label="Secciones de ventas">
                <button class="pestana activa" type="button" data-panel="ventas">Ventas registradas</button>
                <button class="pestana" type="button" data-panel="servicios">Servicios</button>
            </nav>

            <!-- PANEL 1: VENTAS REGISTRADAS (TABLA) -->
            <div id="panel-ventas" data-panel="ventas">
                <section class="herramientas">
                    <div class="buscador">
                        <span class="lupa" aria-hidden="true">⌕</span>
                        <input type="text" placeholder="Buscar por folio o cliente..." aria-label="Buscar por folio o cliente..." data-buscar>
                    </div>
                    <div class="filtro-select">
                        <select data-columna="5" aria-label="Método de pago">
                            <option value="">Todos los pagos</option>
                            <option>Efectivo</option>
                            <option>Transferencia</option>
                            <option>Tarjeta</option>
                        </select>
                    </div>
                    <div class="filtro-fechas">
                        <input type="date" value="<?= date('Y-m-01') ?>" data-fecha-desde aria-label="Fecha inicial">
                        <span aria-hidden="true">-</span>
                        <input type="date" value="<?= date('Y-m-d') ?>" data-fecha-hasta aria-label="Fecha final">
                    </div>
                    <button class="btn-filtrar" type="button">⌕ Filtrar</button>
                </section>

                <section class="tabla-contenedor">
                    <table id="tabla-ventas">
                        <thead>
                            <tr>
                                <th>Folio</th>
                                <th>Fecha y hora</th>
                                <th>Cliente</th>
                                <th>Servicios</th>
                                <th>Productos</th>
                                <th>Método de pago</th>
                                <th>Descuento</th>
                                <th class="monto">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($fila_venta = $resultado_ventas->fetch_assoc()) { 
                                $fecha_unix = strtotime($fila_venta['fecha_hora']);
                                $folio_formateado = "V-" . str_pad($fila_venta['folio_venta'], 4, "0", STR_PAD_LEFT);
                            ?>
                            <tr data-fecha="<?= date('Y-m-d', $fecha_unix) ?>">
                                <td class="id-fila"><?= htmlspecialchars($folio_formateado) ?></td>
                                <td><?= date('d/m/Y H:i', $fecha_unix) ?></td>
                                <td><?= htmlspecialchars($fila_venta['cliente'] ?? 'Público General') ?></td>
                                <!-- Evitamos htmlspecialchars aquí porque GROUP_CONCAT trae etiquetas <br> para separar las líneas -->
                                <td class="texto"><?= $fila_venta['servicios_detalle'] ?: '—' ?></td>
                                <td class="texto"><?= $fila_venta['productos_detalle'] ?: '—' ?></td>
                                <td><?= htmlspecialchars(ucfirst($fila_venta['metodo_pago'])) ?></td>
                                <td><?= $fila_venta['descuento_monto'] > 0 ? '$ ' . number_format($fila_venta['descuento_monto'], 2) : '—' ?></td>
                                <td class="monto">$ <?= number_format($fila_venta['total_venta'], 2) ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>

                    <div class="pie-tabla">
                        <p data-contador></p>
                    </div>
                </section>
            </div>

            <!-- PANEL 2: CATÁLOGO DE SERVICIOS (TARJETAS) -->
            <div id="panel-servicios" data-panel="servicios" hidden>
                <section class="herramientas">
                    <div class="buscador">
                        <span class="lupa" aria-hidden="true">⌕</span>
                        <input type="text" placeholder="Buscar servicio, categoría o ID..." aria-label="Buscar servicio, categoría o ID..." data-buscar>
                    </div>
                    <div class="filtro-select">
                        <select data-categoria aria-label="Categoría">
                            <option value="">Todas las categorías</option>
                            <option>Corte</option>
                            <option>Barba</option>
                            <option>Combo</option>
                            <option>Premium</option>
                            <option>Complemento</option>
                        </select>
                    </div>
                    <button class="btn-agregar" type="button"><span aria-hidden="true">＋</span> Agregar servicio</button>
                </section>

                <section class="grid-servicios">
                    <?php while ($fila_serv = $resultado_servicios->fetch_assoc()) { 
                        // Calculamos las horas y minutos exactos para la tarjeta visual
                        $horas = floor($fila_serv['duracion_min'] / 60);
                        $minutos = $fila_serv['duracion_min'] % 60;
                        $tiempo_str = "";
                        if ($horas > 0) $tiempo_str .= $horas . " h ";
                        if ($minutos > 0) $tiempo_str .= $minutos . " min";
                    ?>
                    <article class="servicio-card" data-categoria="<?= htmlspecialchars(ucfirst($fila_serv['categoria'])) ?>">
                        <div class="servicio-cabeza">
                            <span class="servicio-cat"><?= htmlspecialchars(ucfirst($fila_serv['categoria'])) ?></span>
                            <span class="servicio-id"><?= htmlspecialchars(strtoupper($fila_serv['id_servicio'])) ?></span>
                        </div>
                        <h3><?= htmlspecialchars($fila_serv['nombre']) ?></h3>
                        <p class="servicio-desc"><?= htmlspecialchars($fila_serv['descripcion']) ?></p>
                        <div class="servicio-pie">
                            <div class="servicio-datos">
                                <strong class="servicio-precio">$ <?= number_format($fila_serv['precio'], 2) ?></strong>
                                <span class="servicio-duracion"><?= trim($tiempo_str) ?></span>
                            </div>
                            <div class="acciones">
                                <button class="editar" type="button" aria-label="Editar <?= htmlspecialchars($fila_serv['nombre']) ?>">✎</button>
                                <button class="eliminar" type="button" aria-label="Eliminar <?= htmlspecialchars($fila_serv['nombre']) ?>">✕</button>
                            </div>
                        </div>
                    </article>
                    <?php } ?>
                    <p class="sin-resultados-cards" hidden>No se encontraron servicios</p>
                </section>

                <div class="pie-tabla">
                    <p data-contador></p>
                </div>
            </div>

        </main>

    </div>

    <!-- Script del menú (Verifica que en este JS los enlaces apunten a .php) -->
    <script src="js/PID_menu_d.js"></script>
    <script src="js/PID_datos.js"></script>
    <script src="js/PID_nueva_venta.js"></script>
    <script src="js/PID_tablas.js"></script>
    <script src="js/PID_tarjetas.js"></script>
</body>
</html>
