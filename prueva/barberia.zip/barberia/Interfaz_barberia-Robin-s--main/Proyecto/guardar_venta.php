<?php
session_start();
include("conexion/db.php");

// Recibimos el paquete de datos enviado por JavaScript
$datos = json_decode(file_get_contents("php://input"), true);

if (!$datos) {
    echo json_encode(["exito" => false, "error" => "No se recibieron datos"]);
    exit;
}

$id_usuario = isset($_SESSION['id_usuario']) ? $_SESSION['id_usuario'] : 1; 
$cliente_nombre = trim($datos['cliente']);
$telefono = trim($datos['telefono']);
$pago = strtolower($datos['pago']); 
$subtotal = $datos['subtotal'];
$descuento = $datos['descuento'];
$total = $datos['total'];

// Iniciamos la transacción (si algo falla, no se guarda nada a medias)
$conexion->begin_transaction();

try {
    $id_cliente = null;

if (!empty($cliente_nombre)) {
    $stmt_cli = $conexion->prepare("SELECT id_cliente FROM clientes WHERE nombre = ?");
    $stmt_cli->bind_param("s", $cliente_nombre);
    $stmt_cli->execute();
    $res_cli = $stmt_cli->get_result();

    if ($res_cli->num_rows > 0) {
        $id_cliente = $res_cli->fetch_assoc()['id_cliente'];
    } else {
        // Se asume que id_cliente es AUTO_INCREMENT
        $stmt_ins_cli = $conexion->prepare("INSERT INTO clientes (nombre, telefono) VALUES (?, ?)");
        $stmt_ins_cli->bind_param("ss", $cliente_nombre, $telefono);
        $stmt_ins_cli->execute();
        $id_cliente = $conexion->insert_id; // <- Cambio clave aquí
        $stmt_ins_cli->close();
    }
    $stmt_cli->close();
}

    // 2. Guarda la venta principal
    $stmt_v = $conexion->prepare("INSERT INTO ventas (id_cliente, metodo_pago, subtotal, descuento_monto, total_venta, id_usuario, estado) VALUES (?, ?, ?, ?, ?, ?, 'completada')");
    $stmt_v->bind_param("isdddi", $id_cliente, $pago, $subtotal, $descuento, $total, $id_usuario);
    $stmt_v->execute();
    $folio_venta = $stmt_v->insert_id;
    $stmt_v->close();

    // 3. Guarda los servicios seleccionados
    if (!empty($datos['servicios'])) {
        $stmt_s = $conexion->prepare("INSERT INTO detalle_venta_servicio (folio_venta, id_servicio, cantidad, precio_cobrado) VALUES (?, ?, 1, ?)");
        foreach ($datos['servicios'] as $s) {
            $stmt_s->bind_param("isd", $folio_venta, $s['id'], $s['precio']);
            $stmt_s->execute();
        }
        $stmt_s->close();
    }

    // 4. Guarda los productos y resta el stock
    if (!empty($datos['productos'])) {
        $stmt_p = $conexion->prepare("INSERT INTO detalle_venta_producto (folio_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)");
        $stmt_upd_p = $conexion->prepare("UPDATE productos SET stock_actual = stock_actual - ? WHERE id_producto = ?");
        
        foreach ($datos['productos'] as $p) {
            $subt_p = $p['cant'] * $p['precio'];
            $stmt_p->bind_param("isidd", $folio_venta, $p['id'], $p['cant'], $p['precio'], $subt_p);
            $stmt_p->execute();

            // Descuenta del stock
            $stmt_upd_p->bind_param("is", $p['cant'], $p['id']);
            $stmt_upd_p->execute();
        }
        $stmt_p->close();
        $stmt_upd_p->close();
    }

    // Si todo salió bien, guardamos los cambios definitivamente
    $conexion->commit();
    echo json_encode(["exito" => true, "folio" => $folio_venta]);

} catch (Exception $e) {
    // Si hubo algún error, deshacemos todos los pasos
    $conexion->rollback();
    echo json_encode(["exito" => false, "error" => "Error al guardar en la base de datos"]);
}

$conexion->close();
?>