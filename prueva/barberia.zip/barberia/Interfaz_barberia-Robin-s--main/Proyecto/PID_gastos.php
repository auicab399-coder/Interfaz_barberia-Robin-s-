<?php
include("conexion/db.php");

// 1. Obtener los datos del propietario para el encabezado
$sql_usuario = "SELECT nombre FROM usuarios WHERE id_usuario = 1";
$resultado_usuario = $conexion->query($sql_usuario);
$datos_usuario = $resultado_usuario->fetch_assoc();

// 2. Obtener el historial de gastos uniendo la tabla gastos con categorias_gastos
$sql_gastos = "SELECT g.id_gasto, g.fecha_hora, cg.nombre_categoria, g.descripcion, g.monto 
               FROM gastos g 
               INNER JOIN categorias_gastos cg ON g.id_categoria = cg.id_categoria
               ORDER BY g.fecha_hora DESC";
$resultado_gastos = $conexion->query($sql_gastos);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gastos · Barbería Robin's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
</head>
<body class="pag-gastos">

    <div class="app">

        <div id="menu-root"></div>

        <main class="app-contenido">

            <header class="encabezado">
                <div class="titulo">
                    <h1>Gastos</h1>
                    <p>Registro y consulta de gastos</p>
                </div>
                <div class="usuario">
                    <span class="usuario-icono">LH</span>
                    <div class="usuario-datos">
                        <!-- Nombre del usuario dinámico -->
                        <strong><?= htmlspecialchars($datos_usuario['nombre']) ?></strong>
                        <small>Propietario</small>
                    </div>
                </div>
            </header>

            <section class="herramientas">
                <div class="buscador">
                    <span class="lupa" aria-hidden="true">⌕</span>
                    <input type="text" placeholder="Buscar descripción..." aria-label="Buscar descripción..." data-buscar>
                </div>
                <div class="filtro-select">
                    <select data-columna="2" aria-label="Categoría">
                        <option value="">Todas las categorías</option>
                        <option>Insumos</option>
                        <option>Productos para reventa</option>
                        <option>Servicios</option>
                        <option>Mantenimiento</option>
                        <option>Publicidad</option>
                        <option>Otros</option>
                    </select>
                </div>
                <div class="filtro-fechas">
                    <input type="date" value="<?= date('Y-m-d') ?>" data-fecha-desde aria-label="Fecha inicial">
                    <span aria-hidden="true">-</span>
                    <input type="date" value="<?= date('Y-m-d') ?>" data-fecha-hasta aria-label="Fecha final">
                </div>
                <button class="btn-filtrar" type="button">⌕ Filtrar</button>
            </section>

            <section class="tabla-contenedor">
                <table id="tabla-gastos">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Descripción</th>
                            <th>Categoría</th>
                            <th class="monto">Monto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($fila = $resultado_gastos->fetch_assoc()) { 
                            // Formatear la fecha para que se adapte al atributo data-fecha (Y-m-d) y a la vista (d/m/Y)
                            $fecha_unix = strtotime($fila['fecha_hora']);
                            $fecha_filtro = date('Y-m-d', $fecha_unix);
                            $fecha_visible = date('d/m/Y', $fecha_unix);
                        ?>
                        <tr data-fecha="<?= $fecha_filtro ?>">
                            <td><?= $fecha_visible ?></td>
                            <td class="texto"><?= htmlspecialchars($fila['descripcion']) ?></td>
                            <td><?= htmlspecialchars($fila['nombre_categoria']) ?></td>
                            <td class="monto">$ <?= htmlspecialchars(number_format($fila['monto'], 2)) ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <div class="pie-tabla">
                    <p data-contador></p>
                </div>
            </section>

        </main>

    </div>

    <!-- Script del menú (Verifica que en este JS los enlaces apunten a .php) -->
    <script src="js/PID_menu_d.js"></script>
    <script src="js/PID_tablas.js"></script>
</body>
</html>
