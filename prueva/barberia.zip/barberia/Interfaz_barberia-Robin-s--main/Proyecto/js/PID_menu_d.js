(function () {
    const LOGO = "assents/img/logo-barberia-robins.jpeg";
    const PAGINA_LOGIN = "index.html";

    const OPCIONES = [
        { href: "PID_inicio.php",        icono: "", texto: "Inicio" },
        { href: "PID_inventario.php",    icono: "", texto: "Inventario" },
        { href: "PID_ventas.php",        icono: "", texto: "Ventas" },
        { href: "PID_gastos.php",        icono: "", texto: "Gastos" },
        { href: "PID_reportes.php",      icono: "", texto: "Reportes" },
        { href: "PID_configuracion.php", icono: "", texto: "Configuración" }
    ];

    const raiz = document.getElementById("menu-root");
    if (!raiz) return;

    const paginaActual = decodeURIComponent(location.pathname.split("/").pop());

    const enlaces = OPCIONES.map(function (op) {
        const activo = op.href === paginaActual;
        return `
            <a href="${op.href}" class="menu-link${activo ? " activo" : ""}"${activo ? ' aria-current="page"' : ""}>
                ${op.texto}
            </a>`;
    }).join("");

    raiz.insertAdjacentHTML("beforebegin", `
        <button class="menu-btn" id="btnMenu" type="button" aria-label="Abrir o cerrar menú" aria-expanded="false">☰</button>
        <div class="menu-overlay" id="menuOverlay"></div>

        <aside class="menu-lateral" id="menuLateral">
            <div class="menu-logo">
                <img src="${LOGO}" alt="Logo de Barbería Robin's">
            </div>

            <nav class="menu-nav" aria-label="Menú principal">${enlaces}</nav>

            <div class="menu-separador"></div>

            <a href="${PAGINA_LOGIN}" id="btnCerrarSesion" class="menu-cerrar-sesion">
                Cerrar sesión
            </a>
        </aside>
    `);
    raiz.remove();

    // Abrir / cerrar (solo tiene efecto en pantallas pequeñas)
    const btnMenu = document.getElementById("btnMenu");
    const menuLateral = document.getElementById("menuLateral");
    const overlay = document.getElementById("menuOverlay");

    function alternarMenu(abrir) {
        const abierto = abrir !== undefined ? abrir : !menuLateral.classList.contains("menu-abierto");
        menuLateral.classList.toggle("menu-abierto", abierto);
        overlay.classList.toggle("visible", abierto);
        btnMenu.setAttribute("aria-expanded", abierto);
    }

    btnMenu.addEventListener("click", function () { alternarMenu(); });
    overlay.addEventListener("click", function () { alternarMenu(false); });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") alternarMenu(false);
    });

    // Cerrar sesión con confirmación
    document.getElementById("btnCerrarSesion").addEventListener("click", function (e) {
        e.preventDefault();
        if (confirm("¿Deseas cerrar la sesión?")) {
            window.location.replace(PAGINA_LOGIN);
        }
    });
})();
