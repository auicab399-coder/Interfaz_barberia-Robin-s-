(function () {
    const FECHA_TRABAJO = "2026-11-04";
    const PERIODO_DESDE = "2026-11-01";
    const LLAVE = "pid_ventas_nuevas";

    const SERVICIOS = [
        { id: "S01", nombre: "Servicio de corte", precio: 200 },
        { id: "S02", nombre: "Servicio corte de niño", precio: 150 },
        { id: "S03", nombre: "Servicio corte y arreglo de barba", precio: 290 },
        { id: "S04", nombre: "Arreglo de barba / Afeitado completo", precio: 180 },
        { id: "S05", nombre: "Servicio VIP", precio: 300 },
        { id: "S06", nombre: "Servicio VIP + barba", precio: 350 },
        { id: "S07", nombre: "Servicio de corte y facial", precio: 250 },
        { id: "S08", nombre: "Mascarilla negra L", precio: 30 }
    ];

    const PRODUCTOS = [
        { id: "P01", nombre: "Pomada de fijación fuerte 100 g", precio: 140 },
        { id: "P02", nombre: "Cera mate para cabello 100 g", precio: 130 },
        { id: "P03", nombre: "Gel fijador 250 ml", precio: 80 },
        { id: "P04", nombre: "Polvo texturizante 20 g", precio: 110 },
        { id: "P05", nombre: "Crema para peinar 150 ml", precio: 115 },
        { id: "P06", nombre: "Shampoo para cabello 250 ml", precio: 100 },
        { id: "P07", nombre: "Aceite para barba 30 ml", precio: 130 },
        { id: "P08", nombre: "Bálsamo para barba 60 g", precio: 160 },
        { id: "P09", nombre: "Shampoo para barba 120 ml", precio: 110 },
        { id: "P10", nombre: "Loción after shave 120 ml", precio: 140 },
        { id: "P11", nombre: "Peine de madera para barba", precio: 60 },
        { id: "P12", nombre: "Cepillo para barba", precio: 130 }
    ];

    const VENTAS_BASE = [
        { folio: "V-0008", fecha: "2026-11-04", hora: "14:30", cliente: "Jorge Poot", servicios: ["Servicio VIP"], productos: [{ nombre: "Aceite para barba 30 ml", cant: 1 }], pago: "Tarjeta", descuento: 0, total: 430 },
        { folio: "V-0007", fecha: "2026-11-04", hora: "12:45", cliente: "Mateo Uc", servicios: ["Servicio corte de niño"], productos: [], pago: "Transferencia", descuento: 0, total: 150 },
        { folio: "V-0006", fecha: "2026-11-04", hora: "11:15", cliente: "Andrés Canul", servicios: ["Servicio corte y arreglo de barba"], productos: [{ nombre: "Pomada de fijación fuerte 100 g", cant: 1 }], pago: "Efectivo", descuento: 0, total: 430 },
        { folio: "V-0005", fecha: "2026-11-04", hora: "10:00", cliente: "Carlos Méndez", servicios: ["Servicio de corte"], productos: [], pago: "Efectivo", descuento: 0, total: 200 },
        { folio: "V-0004", fecha: "2026-11-03", hora: "17:00", cliente: "Luis Chan", servicios: ["Servicio de corte y facial", "Mascarilla negra L"], productos: [], pago: "Efectivo", descuento: 20, total: 260 },
        { folio: "V-0003", fecha: "2026-11-03", hora: "11:00", cliente: "Mario Canché", servicios: ["Arreglo de barba / Afeitado completo"], productos: [], pago: "Efectivo", descuento: 0, total: 180 },
        { folio: "V-0002", fecha: "2026-11-02", hora: "16:00", cliente: "Daniel Pech", servicios: ["Servicio VIP + barba"], productos: [], pago: "Tarjeta", descuento: 0, total: 350 },
        { folio: "V-0001", fecha: "2026-11-02", hora: "10:30", cliente: "Roberto Tun", servicios: ["Servicio de corte"], productos: [], pago: "Efectivo", descuento: 0, total: 200 }
    ];

    const GASTOS = [
        { fecha: "2026-11-04", descripcion: "Apartado diario para compras futuras", monto: 25 },
        { fecha: "2026-11-03", descripcion: "Compra de insumos de uso interno", monto: 550 },
        { fecha: "2026-11-02", descripcion: "Publicidad y promociones en redes sociales", monto: 250 },
        { fecha: "2026-11-01", descripcion: "Artículos de limpieza", monto: 200 },
        { fecha: "2026-11-01", descripcion: "Agua potable", monto: 150 }
    ];

    let memoria = [];

    function nuevasGuardadas() {
        try {
            const crudo = localStorage.getItem(LLAVE);
            return crudo ? JSON.parse(crudo) : [];
        } catch (e) { return memoria; }
    }

    function guardarNuevas(lista) {
        memoria = lista;
        try { localStorage.setItem(LLAVE, JSON.stringify(lista)); } catch (e) { /* sin almacenamiento */ }
    }

    function todasLasVentas() { return nuevasGuardadas().concat(VENTAS_BASE); }

    function siguienteFolio() {
        const max = todasLasVentas().reduce(function (m, v) {
            return Math.max(m, parseInt(v.folio.replace("V-", ""), 10) || 0);
        }, 0);
        return "V-" + String(max + 1).padStart(4, "0");
    }

    function registrarVenta(venta) {
        const lista = nuevasGuardadas();
        lista.unshift(venta);
        guardarNuevas(lista);
        document.dispatchEvent(new CustomEvent("pid:venta", { detail: venta }));
        return venta;
    }

    function dinero(n) {
        return "$ " + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function fechaCorta(iso) {
        const p = iso.split("-");
        return p[2] + "/" + p[1] + "/" + p[0];
    }

    function escapar(texto) {
        return String(texto).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
    }

    window.PID = {
        FECHA_TRABAJO: FECHA_TRABAJO,
        PERIODO_DESDE: PERIODO_DESDE,
        SERVICIOS: SERVICIOS,
        PRODUCTOS: PRODUCTOS,
        GASTOS: GASTOS,
        todasLasVentas: todasLasVentas,
        ventasNuevas: nuevasGuardadas,
        siguienteFolio: siguienteFolio,
        registrarVenta: registrarVenta,
        dinero: dinero,
        fechaCorta: fechaCorta,
        escapar: escapar,
        reiniciar: function () { guardarNuevas([]); location.reload(); }
    };
})();
