(function () {
    const PID = window.PID;
    if (!PID) return;

    const esc = PID.escapar;
    const $ = function (sel, raiz) { return (raiz || document).querySelector(sel); };

    /* ---------- Aviso (toast) ---------- */
    function aviso(titulo, detalle) {
        let caja = $("#avisos");
        if (!caja) {
            caja = document.createElement("div");
            caja.id = "avisos";
            caja.className = "avisos";
            caja.setAttribute("aria-live", "polite");
            document.body.appendChild(caja);
        }
        const el = document.createElement("div");
        el.className = "aviso-flotante";
        el.innerHTML = "<strong>" + esc(titulo) + "</strong><span>" + esc(detalle) + "</span>";
        caja.appendChild(el);
        setTimeout(function () { el.classList.add("saliendo"); }, 3600);
        setTimeout(function () { el.remove(); }, 4000);
    }
    PID.aviso = aviso;

    /* ---------- Ventana ---------- */
    let productosVenta = [];
    let ultimoFoco = null;

    const opcionesServicios = PID.SERVICIOS.map(function (s) {
        return '<label class="opcion-servicio">' +
            '<input type="checkbox" name="servicio" value="' + esc(s.id) + '">' +
            '<span class="opcion-nombre">' + esc(s.nombre) + '</span>' +
            '<span class="opcion-precio">' + PID.dinero(s.precio) + '</span></label>';
    }).join("");

    const opcionesProductos = PID.PRODUCTOS.map(function (p) {
        return '<option value="' + esc(p.id) + '">' + esc(p.nombre) + ' · ' + PID.dinero(p.precio) + '</option>';
    }).join("");

    document.body.insertAdjacentHTML("beforeend",
        '<div class="modal-fondo" id="modalVenta" hidden>' +
        '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="mvTitulo">' +
        '<form id="formVenta" novalidate>' +
            '<header class="modal-cabeza">' +
                '<div><h2 id="mvTitulo">Nueva venta</h2><p id="mvSubtitulo"></p></div>' +
                '<button type="button" class="modal-cerrar" data-cerrar aria-label="Cerrar">✕</button>' +
            '</header>' +
            '<div class="modal-cuerpo">' +
                '<div class="form-fila">' +
                    '<div class="form-campo"><label for="mvCliente">Cliente</label>' +
                    '<input id="mvCliente" type="text" list="mvClientes" placeholder="Nombre del cliente" autocomplete="off" required>' +
                    '<datalist id="mvClientes"></datalist></div>' +
                    '<div class="form-campo"><label for="mvTelefono">Teléfono <small>(opcional)</small></label>' +
                    '<input id="mvTelefono" type="tel" placeholder="985 000 0000" autocomplete="off"></div>' +
                '</div>' +
                '<fieldset class="form-grupo"><legend>Servicios</legend>' +
                    '<div class="opciones-servicios">' + opcionesServicios + '</div></fieldset>' +
                '<fieldset class="form-grupo"><legend>Productos <small>(opcional)</small></legend>' +
                    '<div class="producto-agregar">' +
                        '<select id="mvProducto" aria-label="Producto">' + opcionesProductos + '</select>' +
                        '<input id="mvCantidad" type="number" min="1" max="20" value="1" aria-label="Cantidad">' +
                        '<button type="button" class="btn-secundario" id="mvAgregarProducto">Agregar</button>' +
                    '</div>' +
                    '<ul class="lista-productos" id="mvListaProductos"></ul></fieldset>' +
                '<div class="form-fila">' +
                    '<fieldset class="form-grupo"><legend>Método de pago</legend>' +
                        '<div class="segmentado">' +
                            '<label><input type="radio" name="pago" value="Efectivo" checked><span>Efectivo</span></label>' +
                            '<label><input type="radio" name="pago" value="Transferencia"><span>Transferencia</span></label>' +
                            '<label><input type="radio" name="pago" value="Tarjeta"><span>Tarjeta</span></label>' +
                        '</div></fieldset>' +
                    '<div class="form-campo"><label for="mvDescuento">Descuento <small>($)</small></label>' +
                    '<input id="mvDescuento" type="number" min="0" step="1" value="0" inputmode="decimal"></div>' +
                '</div>' +
                '<div class="resumen-venta">' +
                    '<div><span>Subtotal</span><strong id="mvSubtotal">$ 0.00</strong></div>' +
                    '<div><span>Descuento</span><strong id="mvDesc">- $ 0.00</strong></div>' +
                '</div>' +
                '<p class="form-error" id="mvError" role="alert" hidden></p>' +
            '</div>' +
            '<footer class="modal-pie">' +
                '<div class="pie-total"><span>Total a cobrar</span><strong id="mvTotal">$ 0.00</strong></div>' +
                '<button type="button" class="btn-cancelar" data-cerrar>Cancelar</button>' +
                '<button type="submit" class="btn-guardar">Registrar venta</button>' +
            '</footer>' +
        '</form></div></div>');

    const fondo = $("#modalVenta");
    const form = $("#formVenta");
    const error = $("#mvError");

    function serviciosElegidos() {
        const ids = Array.prototype.map.call(form.querySelectorAll('input[name="servicio"]:checked'), function (i) { return i.value; });
        return PID.SERVICIOS.filter(function (s) { return ids.indexOf(s.id) !== -1; });
    }

    function calcular() {
        const sub = serviciosElegidos().reduce(function (t, s) { return t + s.precio; }, 0) +
            productosVenta.reduce(function (t, p) { return t + p.precio * p.cant; }, 0);
        const desc = Math.max(0, parseFloat($("#mvDescuento").value) || 0);
        $("#mvSubtotal").textContent = PID.dinero(sub);
        $("#mvDesc").textContent = "- " + PID.dinero(desc);
        $("#mvTotal").textContent = PID.dinero(Math.max(0, sub - desc));
        return { sub: sub, desc: desc, total: Math.max(0, sub - desc) };
    }

    function pintarProductos() {
        const lista = $("#mvListaProductos");
        lista.innerHTML = productosVenta.map(function (p, i) {
            return '<li><span>' + esc(p.nombre) + ' <b>×' + p.cant + '</b></span>' +
                '<span class="lp-precio">' + PID.dinero(p.precio * p.cant) + '</span>' +
                '<button type="button" class="eliminar" data-quitar="' + i + '" aria-label="Quitar ' + esc(p.nombre) + '">✕</button></li>';
        }).join("");
        calcular();
    }

    function mostrarError(msg) {
        error.textContent = msg;
        error.hidden = false;
    }

    function abrir() {
        ultimoFoco = document.activeElement;
        form.reset();
        productosVenta = [];
        pintarProductos();
        form.querySelectorAll(".opcion-servicio").forEach(function (l) { l.classList.remove("marcada"); });
        error.hidden = true;
        $("#mvSubtitulo").textContent = "Nuevo Registro";

        fondo.hidden = false;
        document.body.classList.add("modal-abierto");
        requestAnimationFrame(function () { fondo.classList.add("visible"); });
        setTimeout(function () { $("#mvCliente").focus(); }, 60);
    }

    function cerrar() {
        fondo.classList.remove("visible");
        document.body.classList.remove("modal-abierto");
        setTimeout(function () { fondo.hidden = true; }, 220);
        if (ultimoFoco && ultimoFoco.focus) ultimoFoco.focus();
    }

    document.querySelectorAll("[data-nueva-venta]").forEach(function (b) { b.addEventListener("click", abrir); });
    fondo.addEventListener("mousedown", function (e) { if (e.target === fondo) cerrar(); });
    fondo.querySelectorAll("[data-cerrar]").forEach(function (b) { b.addEventListener("click", cerrar); });

    form.addEventListener("change", function (e) {
        if (e.target.name === "servicio") e.target.closest(".opcion-servicio").classList.toggle("marcada", e.target.checked);
        error.hidden = true;
        calcular();
    });
    $("#mvDescuento").addEventListener("input", function () { error.hidden = true; calcular(); });

    $("#mvAgregarProducto").addEventListener("click", function () {
        const prodId = $("#mvProducto").value;
        const prod = PID.PRODUCTOS.filter(function (p) { return p.id === prodId; })[0];
        const cant = Math.min(20, Math.max(1, parseInt($("#mvCantidad").value, 10) || 1));
        if (!prod) return;
        
        // Agregamos también el id_producto porque la base de datos lo necesita para identificarlo
        const existente = productosVenta.filter(function (p) { return p.id === prod.id; })[0];
        if (existente) existente.cant = Math.min(20, existente.cant + cant);
        else productosVenta.push({ id: prod.id, nombre: prod.nombre, precio: prod.precio, cant: cant });
        
        $("#mvCantidad").value = 1;
        error.hidden = true;
        pintarProductos();
    });

    $("#mvListaProductos").addEventListener("click", function (e) {
        const b = e.target.closest("[data-quitar]");
        if (!b) return;
        productosVenta.splice(parseInt(b.dataset.quitar, 10), 1);
        pintarProductos();
    });

    // Envío de datos a PHP mediante Fetch API
    form.addEventListener("submit", function (e) {
        e.preventDefault();
        const cliente = $("#mvCliente").value.trim();
        const servicios = serviciosElegidos();
        const t = calcular();

        if (!servicios.length && !productosVenta.length) { mostrarError("Elige al menos un servicio o un producto."); return; }
        if (t.desc > t.sub) { mostrarError("El descuento no puede ser mayor al subtotal."); $("#mvDescuento").focus(); return; }

        // Empaquetamos toda la información de la venta
        const datosVenta = {
            cliente: cliente,
            telefono: $("#mvTelefono").value.trim(),
            servicios: servicios.map(function(s) { return { id: s.id, precio: s.precio }; }),
            productos: productosVenta.map(function(p) { return { id: p.id, cant: p.cant, precio: p.precio }; }),
            pago: (form.querySelector('input[name="pago"]:checked') || {}).value || "Efectivo",
            subtotal: t.sub,
            descuento: t.desc,
            total: t.total
        };

        const btnGuardar = form.querySelector('.btn-guardar');
        btnGuardar.disabled = true;
        btnGuardar.textContent = "Guardando...";

        // Mandamos el paquete al archivo guardar_venta.php
        fetch('guardar_venta.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datosVenta)
        })
        .then(res => res.json())
        .then(data => {
            if (data.exito) {
                cerrar();
                aviso("Venta registrada", (cliente || "Público General") + " · " + PID.dinero(t.total));
                setTimeout(() => location.reload(), 1500); // Recarga la página para mostrar la venta nueva
            } else {
                mostrarError("Error: " + data.error);
                btnGuardar.disabled = false;
                btnGuardar.textContent = "Registrar venta";
            }
        })
        .catch(err => {
            mostrarError("Error de conexión con el servidor.");
            btnGuardar.disabled = false;
            btnGuardar.textContent = "Registrar venta";
        });
    });
})();