<?php
include("conexion/db.php");

// 1. Obtener los datos del propietario para el encabezado
$sql_usuario = "SELECT nombre FROM usuarios WHERE id_usuario = 1";
$resultado_usuario = $conexion->query($sql_usuario);
$datos_usuario = $resultado_usuario->fetch_assoc();

// 2. Obtener la lista de productos para la primera tabla
$sql_productos = "SELECT id_producto, nombre, categoria, costo_compra, precio_venta, stock_actual, stock_minimo FROM productos ORDER BY id_producto ASC";
$resultado_productos = $conexion->query($sql_productos);

// 3. Obtener la lista de materiales/insumos para la segunda tabla
$sql_materiales = "SELECT id_material, nombre, unidad, servicios_aplicables, costo_unitario, existencia, minimo FROM materiales_insumos ORDER BY id_material ASC";
$resultado_materiales = $conexion->query($sql_materiales);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario · Barbería Robin's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
</head>
<body class="pag-inventario">

    <div class="app">

        <div id="menu-root"></div>

        <main class="app-contenido">

            <header class="encabezado">
                <div class="titulo">
                    <h1>Inventario</h1>
                    <p>Productos para venta y materiales de uso interno</p>
                </div>
                <div class="usuario">
                    <span class="usuario-icono">LH</span>
                    <div class="usuario-datos">
                        <strong><?= htmlspecialchars($datos_usuario['nombre']) ?></strong>
                        <small>Propietario</small>
                    </div>
                </div>
            </header>

            <nav class="pestanas" aria-label="Secciones del inventario">
                <button class="pestana activa" type="button" data-tabla="productos">Productos para venta</button>
                <button class="pestana" type="button" data-tabla="materiales">Materiales de uso interno</button>
            </nav>

            <section class="herramientas">
                <div class="buscador">
                    <span class="lupa" aria-hidden="true">⌕</span>
                    <input type="text" placeholder="Buscar por nombre, categoría o ID..." aria-label="Buscar por nombre, categoría o ID..." data-buscar>
                </div>
                <button class="btn-agregar" type="button"><span aria-hidden="true">＋</span> Agregar</button>
            </section>

            <section class="tabla-contenedor">
                <!-- TABLA 1: PRODUCTOS PARA VENTA -->
                <table id="tabla-productos">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Costo</th>
                            <th>Precio de venta</th>
                            <th>Stock</th>
                            <th>Mínimo</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($fila_prod = $resultado_productos->fetch_assoc()) { 
                            // Lógica de estado dinámico para productos
                            $estado_prod = ($fila_prod['stock_actual'] <= $fila_prod['stock_minimo']) ? "Bajo" : "Disponible";
                            $clase_estado_prod = ($estado_prod == "Bajo") ? "estado bg-rojo" : "estado"; // Asumiendo que usarás una clase CSS para resaltar si quieres
                        ?>
                        <tr>
                            <td class="id-fila"><?= htmlspecialchars(strtoupper($fila_prod['id_producto'])) ?></td>
                            <td><?= htmlspecialchars($fila_prod['nombre']) ?></td>
                            <td><?= htmlspecialchars($fila_prod['categoria']) ?></td>
                            <td>$ <?= htmlspecialchars(number_format($fila_prod['costo_compra'], 2)) ?></td>
                            <td>$ <?= htmlspecialchars(number_format($fila_prod['precio_venta'], 2)) ?></td>
                            <td><?= htmlspecialchars($fila_prod['stock_actual']) ?></td>
                            <td><?= htmlspecialchars($fila_prod['stock_minimo']) ?></td>
                            <td><span class="<?= $clase_estado_prod ?>"><?= $estado_prod ?></span></td>
                            <td class="acciones">
                                <button class="editar" type="button" aria-label="Editar <?= htmlspecialchars($fila_prod['nombre']) ?>">✎</button>
                                <button class="eliminar" type="button" aria-label="Eliminar <?= htmlspecialchars($fila_prod['nombre']) ?>">✕</button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <!-- TABLA 2: MATERIALES DE USO INTERNO -->
                <table id="tabla-materiales" hidden>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Material</th>
                            <th>Unidad</th>
                            <th>Se usa en</th>
                            <th>Costo unitario</th>
                            <th>Existencia</th>
                            <th>Mínimo</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($fila_mat = $resultado_materiales->fetch_assoc()) { 
                            // Lógica de estado dinámico para materiales
                            $estado_mat = ($fila_mat['existencia'] <= $fila_mat['minimo']) ? "Bajo" : "Suficiente";
                            $clase_estado_mat = ($estado_mat == "Bajo") ? "estado bg-rojo" : "estado"; 
                        ?>
                        <tr>
                            <td class="id-fila"><?= htmlspecialchars(strtoupper($fila_mat['id_material'])) ?></td>
                            <td class="texto"><?= htmlspecialchars($fila_mat['nombre']) ?></td>
                            <td><?= htmlspecialchars(ucfirst($fila_mat['unidad'])) ?></td>
                            <td class="texto"><?= htmlspecialchars($fila_mat['servicios_aplicables']) ?></td>
                            <td>$ <?= htmlspecialchars(number_format($fila_mat['costo_unitario'], 2)) ?></td>
                            <td><?= htmlspecialchars($fila_mat['existencia']) ?></td>
                            <td><?= htmlspecialchars($fila_mat['minimo']) ?></td>
                            <td><span class="<?= $clase_estado_mat ?>"><?= $estado_mat ?></span></td>
                            <td class="acciones">
                                <button class="editar" type="button" aria-label="Editar <?= htmlspecialchars($fila_mat['nombre']) ?>">✎</button>
                                <button class="eliminar" type="button" aria-label="Eliminar <?= htmlspecialchars($fila_mat['nombre']) ?>">✕</button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <div class="pie-tabla">
                    <p data-contador></p>
                </div>
            </section>

        </main>

    </div>

    <!-- Script del menú (Verifica que en este JS los enlaces apunten a .php) -->
    <script src="js/PID_menu_d.js"></script>
    <script src="js/PID_tablas.js"></script>
</body>
</html>