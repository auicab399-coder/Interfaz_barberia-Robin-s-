<?php
include("conexion/db.php");

// 1. Obtener los datos del propietario (tabla usuarios)
$sql_usuario = "SELECT nombre, nombre_usuario, rol FROM usuarios WHERE id_usuario = 1";
$resultado_usuario = $conexion->query($sql_usuario);
$datos_usuario = $resultado_usuario->fetch_assoc();

// 2. Obtener el precio de cancelación (tabla servicios, id 's09')
$sql_cargo = "SELECT precio FROM servicios WHERE id_servicio = 's09'";
$resultado_cargo = $conexion->query($sql_cargo);
$datos_cargo = $resultado_cargo->fetch_assoc();

// 3. Obtener los datos generales del negocio (la tabla que acabas de crear)
$sql_negocio = "SELECT nombre, giro, direccion, telefono, citas FROM configuracion_negocio WHERE id_config = 1";
$resultado_negocio = $conexion->query($sql_negocio);
$datos_negocio = $resultado_negocio->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración · Barbería Robin's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
</head>
<body class="pag-configuracion">

    <div class="app">

        <div id="menu-root"></div>

        <main class="app-contenido">

            <header class="encabezado">
                <div class="titulo">
                    <h1>Configuración</h1>
                    <p>Datos del negocio y acceso al sistema</p>
                </div>
                <div class="usuario">
                    <span class="usuario-icono">LH</span>
                    <div class="usuario-datos">
                        <strong><?= htmlspecialchars($datos_usuario['nombre']) ?></strong>
                        <small>Propietario</small>
                    </div>
                </div>
            </header>

            <section class="panel-cuerpo">

                <div class="panel-card formulario">
                    <h2>Datos del negocio</h2>
                    
                    <label for="nombre">Nombre del negocio</label>
                    <input id="nombre" type="text" value="<?= htmlspecialchars($datos_negocio['nombre']) ?>">

                    <label for="giro">Giro</label>
                    <input id="giro" type="text" value="<?= htmlspecialchars($datos_negocio['giro']) ?>">

                    <label for="direccion">Dirección</label>
                    <input id="direccion" type="text" value="<?= htmlspecialchars($datos_negocio['direccion']) ?>">

                    <label for="telefono">Teléfono</label>
                    <input id="telefono" type="tel" value="<?= htmlspecialchars($datos_negocio['telefono']) ?>">

                    <label for="citas">Atención de citas</label>
                    <input id="citas" type="text" value="<?= htmlspecialchars($datos_negocio['citas']) ?>">
                </div>

                <div class="panel-card logo-config">
                    <img class="logo-imagen" src="assents/img/logo-barberia-robins.jpeg" alt="Logo de Barbería Robin's">
                    <button class="btn-secundario" type="button">Cambiar logo</button>
                </div>

                <div class="panel-card operacion">
                    <h2>Operación y acceso</h2>
                    
                    <label for="propietario">Propietario y barbero</label>
                    <input id="propietario" type="text" value="<?= htmlspecialchars($datos_usuario['nombre']) ?>">

                    <label for="cargo">Cargo por cancelación tardía (menos de 1 hora)</label>
                    <input id="cargo" type="text" value="$ <?= htmlspecialchars($datos_cargo['precio']) ?>">

                    <label for="usuario">Usuario del sistema</label>
                    <input id="usuario" type="text" value="<?= htmlspecialchars($datos_usuario['nombre_usuario']) ?>" readonly>

                    <label for="rol">Rol</label>
                    <input id="rol" type="text" value="<?= ucfirst(htmlspecialchars($datos_usuario['rol'])) ?>" readonly>
                </div>

            </section>

            <div class="pie-config">
                <button class="btn-guardar" type="button">Guardar cambios</button>
            </div>

        </main>

    </div>

    <!-- Script del menú (Verifica que en este JS los enlaces apunten a .php) -->
    <script src="js/PID_menu_d.js"></script>
    <script src="js/PID_tarjetas.js"></script>
</body>
</html>