<?php
// Incluye la conexión (asegúrate de que el archivo se llame db.php)
include("conexion/db.php");

// Consulta de lectura a la tabla servicios
$sql = "SELECT id_servicio, nombre, categoria, duracion_min, precio, estado FROM servicios";
$resultado = $conexion->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualización de Servicios - Barbería Robin's</title>
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #121212;
            color: #ffffff;
            padding: 30px;
        }
        .contenedor {
            max-width: 950px;
            margin: 0 auto;
            background: #1e1e1e;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        }
        h1 {
            color: #e50914;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #333;
            padding: 10px 12px;
            text-align: left;
        }
        th {
            background-color: #2a2a2a;
            color: #e50914;
        }
        tr:nth-child(even) {
            background-color: #181818;
        }
        tr:hover {
            background-color: #252525;
        }
        .btn-volver {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 16px;
            background-color: #e50914;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="contenedor">
    <h1>Servicios Registrados (Base de Datos)</h1>
    <p>Registros recuperados dinámicamente desde MySQL (<code>barberia_robins.servicios</code>):</p>

    <table>
        <thead>
            <tr>
                <th>Código</th>
                <th>Nombre del Servicio</th>
                <th>Categoría</th>
                <th>Duración (min)</th>
                <th>Precio</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($fila = $resultado->fetch_assoc()) { ?>
            <tr>
                <td><?= htmlspecialchars($fila['id_servicio']) ?></td>
                <td><?= htmlspecialchars($fila['nombre']) ?></td>
                <td><?= htmlspecialchars($fila['categoria']) ?></td>
                <td><?= htmlspecialchars($fila['duracion_min']) ?> min</td>
                <td>$<?= htmlspecialchars(number_format($fila['precio'], 2)) ?></td>
                <td><?= htmlspecialchars($fila['estado']) ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <a href="PID_inicio.html" class="btn-volver">← Volver al Menú Principal</a>
</div>

</body>
</html>
<?php
$conexion->close();
?>