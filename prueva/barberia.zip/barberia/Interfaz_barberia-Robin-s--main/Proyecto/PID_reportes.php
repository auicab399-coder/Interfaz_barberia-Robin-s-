<?php
include("conexion/db.php");

// 1. Obtener los datos del propietario
$sql_usuario = "SELECT nombre FROM usuarios WHERE id_usuario = 1";
$datos_usuario = $conexion->query($sql_usuario)->fetch_assoc();

// 2. Calcular Totales para las Tarjetas Superiores (Ventas completadas y Gastos)
$sql_totales_ventas = "SELECT SUM(total_venta) as total_ventas FROM ventas WHERE estado = 'completada'";
$total_ventas = $conexion->query($sql_totales_ventas)->fetch_assoc()['total_ventas'] ?? 0;

$sql_totales_gastos = "SELECT SUM(monto) as total_gastos FROM gastos";
$total_gastos = $conexion->query($sql_totales_gastos)->fetch_assoc()['total_gastos'] ?? 0;

$ganancia = $total_ventas - $total_gastos;

// 3. Obtener Movimientos (Uniendo Ventas y Gastos en una sola lista ordenada por fecha)
$sql_movimientos = "
    SELECT fecha_hora, 'Venta' AS tipo, CONCAT('Venta Folio V-', LPAD(folio_venta, 4, '0')) AS descripcion, total_venta AS monto 
    FROM ventas WHERE estado = 'completada'
    UNION ALL 
    SELECT fecha_hora, 'Gasto' AS tipo, descripcion, monto 
    FROM gastos
    ORDER BY fecha_hora DESC";
$resultado_movimientos = $conexion->query($sql_movimientos);

// 4. Obtener Servicios más realizados y sus ingresos
$sql_serv_reporte = "
    SELECT s.nombre, SUM(dvs.cantidad) as veces, SUM(dvs.cantidad * dvs.precio_cobrado) as ingresos 
    FROM detalle_venta_servicio dvs 
    INNER JOIN servicios s ON dvs.id_servicio = s.id_servicio 
    INNER JOIN ventas v ON dvs.folio_venta = v.folio_venta 
    WHERE v.estado = 'completada' 
    GROUP BY s.id_servicio 
    ORDER BY ingresos DESC";
$resultado_serv_reporte = $conexion->query($sql_serv_reporte);

// 5. Obtener Productos vendidos, ingresos y stock actual
$sql_prod_reporte = "
    SELECT p.nombre, COALESCE(SUM(dvp.cantidad), 0) as vendidos, COALESCE(SUM(dvp.subtotal), 0) as ingresos, p.stock_actual, p.stock_minimo 
    FROM productos p 
    LEFT JOIN detalle_venta_producto dvp ON p.id_producto = dvp.id_producto 
    LEFT JOIN ventas v ON dvp.folio_venta = v.folio_venta AND v.estado = 'completada'
    GROUP BY p.id_producto 
    ORDER BY vendidos DESC, p.nombre ASC";
$resultado_prod_reporte = $conexion->query($sql_prod_reporte);

// 6. Obtener Insumos
$sql_insumos_reporte = "SELECT nombre, existencia, minimo, costo_unitario FROM materiales_insumos ORDER BY nombre ASC";
$resultado_insumos_reporte = $conexion->query($sql_insumos_reporte);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes · Barbería Robin's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
</head>
<body class="pag-reportes">

    <div class="app">

        <div id="menu-root"></div>

        <main class="app-contenido">

            <header class="encabezado">
                <div class="titulo">
                    <h1>Reportes</h1>
                    <p>Consulta de información financiera y de inventario</p>
                </div>
                <div class="usuario">
                    <span class="usuario-icono">LH</span>
                    <div class="usuario-datos">
                        <strong><?= htmlspecialchars($datos_usuario['nombre']) ?></strong>
                        <small>Propietario</small>
                    </div>
                </div>
            </header>

            <section class="filtros-reporte">
                <div class="filtro-fechas">
                    <input type="date" value="<?= date('Y-m-01') ?>" data-fecha-desde aria-label="Fecha inicial">
                    <span aria-hidden="true">-</span>
                    <input type="date" value="<?= date('Y-m-d') ?>" data-fecha-hasta aria-label="Fecha final">
                </div>
                <button class="btn-filtrar" type="button">⌕ Filtrar</button>
            </section>

            <section class="resumen">
                <article class="tarjeta ventas">
                    <div class="informacion">
                        <p>Ventas totales</p>
                        <h2>$ <?= number_format($total_ventas, 2) ?></h2>
                    </div>
                </article>
                <article class="tarjeta gastos">
                    <div class="informacion">
                        <p>Gastos totales</p>
                        <h2>$ <?= number_format($total_gastos, 2) ?></h2>
                    </div>
                </article>
                <article class="tarjeta ganancias">
                    <div class="informacion">
                        <p>Ganancia</p>
                        <h2>$ <?= number_format($ganancia, 2) ?></h2>
                    </div>
                </article>
            </section>

            <nav class="pestanas" aria-label="Tipo de reporte">
                <button class="pestana activa" type="button" data-tabla="movimientos">Movimientos</button>
                <button class="pestana" type="button" data-tabla="servicios">Servicios</button>
                <button class="pestana" type="button" data-tabla="productos">Productos</button>
                <button class="pestana" type="button" data-tabla="insumos">Insumos</button>
            </nav>

            <section class="tabla-contenedor">
                <!-- TABLA MOVIMIENTOS -->
                <table id="tabla-movimientos">
                    <thead>
                        <tr><th>Fecha</th><th>Tipo</th><th>Descripción</th><th class="monto">Monto</th></tr>
                    </thead>
                    <tbody>
                        <?php while ($fila_mov = $resultado_movimientos->fetch_assoc()) { 
                            $fecha_unix = strtotime($fila_mov['fecha_hora']);
                            $es_gasto = ($fila_mov['tipo'] == 'Gasto');
                            $clase_monto = $es_gasto ? 'negativo' : '';
                        ?>
                        <tr data-fecha="<?= date('Y-m-d', $fecha_unix) ?>">
                            <td><?= date('d/m/Y', $fecha_unix) ?></td>
                            <td><?= htmlspecialchars($fila_mov['tipo']) ?></td>
                            <td class="texto"><?= htmlspecialchars($fila_mov['descripcion']) ?></td>
                            <td class="monto"><span class="<?= $clase_monto ?>">$ <?= number_format($fila_mov['monto'], 2) ?></span></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <!-- TABLA SERVICIOS -->
                <table id="tabla-servicios" hidden>
                    <thead>
                        <tr><th>Servicio</th><th>Veces realizado</th><th class="monto">Ingresos</th></tr>
                    </thead>
                    <tbody>
                        <?php while ($fila_serv = $resultado_serv_reporte->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($fila_serv['nombre']) ?></td>
                            <td><?= htmlspecialchars($fila_serv['veces']) ?></td>
                            <td class="monto">$ <?= number_format($fila_serv['ingresos'], 2) ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <!-- TABLA PRODUCTOS -->
                <table id="tabla-productos" hidden>
                    <thead>
                        <tr><th>Producto</th><th>Vendidos</th><th>Ingresos</th><th>Existencia</th><th>Mínimo</th><th>Estado</th></tr>
                    </thead>
                    <tbody>
                        <?php while ($fila_prod = $resultado_prod_reporte->fetch_assoc()) { 
                            $estado_prod = ($fila_prod['stock_actual'] <= $fila_prod['stock_minimo']) ? "Bajo" : "Disponible";
                            $clase_estado_prod = ($estado_prod == "Bajo") ? "estado bg-rojo" : "estado";
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($fila_prod['nombre']) ?></td>
                            <td><?= htmlspecialchars($fila_prod['vendidos']) ?></td>
                            <td>$ <?= number_format($fila_prod['ingresos'], 2) ?></td>
                            <td><?= htmlspecialchars($fila_prod['stock_actual']) ?></td>
                            <td><?= htmlspecialchars($fila_prod['stock_minimo']) ?></td>
                            <td><span class="<?= $clase_estado_prod ?>"><?= $estado_prod ?></span></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <!-- TABLA INSUMOS -->
                <table id="tabla-insumos" hidden>
                    <thead>
                        <tr><th>Material</th><th>Existencia</th><th>Mínimo</th><th>Costo unitario</th><th>Estado</th></tr>
                    </thead>
                    <tbody>
                        <?php while ($fila_ins = $resultado_insumos_reporte->fetch_assoc()) { 
                            $estado_ins = ($fila_ins['existencia'] <= $fila_ins['minimo']) ? "Bajo" : "Suficiente";
                            $clase_estado_ins = ($estado_ins == "Bajo") ? "estado bg-rojo" : "estado";
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($fila_ins['nombre']) ?></td>
                            <td><?= htmlspecialchars($fila_ins['existencia']) ?></td>
                            <td><?= htmlspecialchars($fila_ins['minimo']) ?></td>
                            <td>$ <?= number_format($fila_ins['costo_unitario'], 2) ?></td>
                            <td><span class="<?= $clase_estado_ins ?>"><?= $estado_ins ?></span></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <div class="pie-tabla">
                    <p data-contador></p>
                </div>
            </section>

        </main>

    </div>

    <!-- Script del menú -->
    <script src="js/PID_menu_d.js"></script>
    <script src="js/PID_tablas.js"></script>
    <script src="js/PID_tarjetas.js"></script>
</body>
</html>