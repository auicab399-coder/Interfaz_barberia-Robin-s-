(function () {
    const SELECTOR = ".tarjeta, .servicio-card, .lectura-item, .panel-card, .panel-analisis";
    const CONTROLES = "input, select, textarea, button, a, label";

    function preparar() {
        document.querySelectorAll(SELECTOR).forEach(function (el) {
            if (el.dataset.lista) return;
            el.dataset.lista = "1";
            if (!el.matches(".panel-card")) el.setAttribute("tabindex", "0");
            if (!el.hasAttribute("aria-pressed") && !el.matches(".panel-card")) el.setAttribute("aria-pressed", "false");
        });
    }

    function seleccionar(el, forzar) {
        const activar = forzar === true ? true : !el.classList.contains("seleccionada");
        Array.prototype.forEach.call(el.parentElement.children, function (hermano) {
            if (hermano.matches(SELECTOR)) {
                hermano.classList.remove("seleccionada");
                if (hermano.hasAttribute("aria-pressed")) hermano.setAttribute("aria-pressed", "false");
            }
        });
        if (activar) {
            el.classList.add("seleccionada");
            if (el.hasAttribute("aria-pressed")) el.setAttribute("aria-pressed", "true");
        }
    }

    document.addEventListener("click", function (e) {
        const el = e.target.closest(SELECTOR);
        if (!el) return;
        seleccionar(el, e.target.closest(CONTROLES) ? true : undefined);
    });

    document.addEventListener("keydown", function (e) {
        if (e.key !== "Enter" && e.key !== " ") return;
        const el = e.target;
        if (el.matches && el.matches(SELECTOR) && !el.matches(".panel-card")) {
            e.preventDefault();
            seleccionar(el);
        }
    });

    preparar();
    new MutationObserver(preparar).observe(document.body, { childList: true, subtree: true });
})();
