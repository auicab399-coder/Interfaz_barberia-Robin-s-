/**
 * PID_acciones.js — conecta los botones de cada pantalla con los endpoints PHP / MySQL:
 *   Gastos         → guardar_gasto.php          (Agregar nuevo gasto)
 *   Ventas         → guardar_servicio.php       (Agregar / editar / eliminar servicio)
 *   Inventario     → guardar_inventario.php     (Agregar / editar / eliminar producto o material)
 *   Configuración  → guardar_configuracion.php  (Guardar cambios)
 * La venta nueva se maneja en PID_nueva_venta.js → guardar_venta.php
 */
(function () {
    "use strict";
    const F = window.PIDForm;
    if (!F) return;

    const body = document.body;
    const $ = function (sel, raiz) { return (raiz || document).querySelector(sel); };
    const todos = function (sel, raiz) { return Array.prototype.slice.call((raiz || document).querySelectorAll(sel)); };
    const mayus = function (t) { return t ? t.charAt(0).toUpperCase() + t.slice(1) : t; };
    const dinero = function (n) { return "$ " + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };

    /* ==================================================================
       GASTOS
       ================================================================== */
    if (body.classList.contains("pag-gastos")) {
        const btn = $("[data-nuevo-gasto]");
        if (btn) btn.addEventListener("click", function () {
            const cats = window.PID_CATEGORIAS_GASTO || [];
            F.modal({
                titulo: "Nuevo gasto",
                subtitulo: "Se registrará con tu usuario",
                textoGuardar: "Guardar gasto",
                campos: [
                    { name: "id_categoria", label: "Categoría", tipo: "select", requerido: true,
                      opciones: [{ valor: "", texto: "Selecciona una categoría" }].concat(
                          cats.map(function (c) { return { valor: String(c.id), texto: c.nombre }; })) },
                    { name: "descripcion", label: "Descripción", tipo: "text", requerido: true, maxLen: 255, placeholder: "Ej. Compra de navajas" },
                    { name: "monto", label: "Monto ($)", tipo: "number", requerido: true, min: 0.01, max: 99999999.99, step: "0.01", ancho: 1 },
                    { name: "metodo_pago", label: "Método de pago", tipo: "select", requerido: true, valor: "efectivo", ancho: 1,
                      opciones: [
                          { valor: "efectivo", texto: "Efectivo" },
                          { valor: "transferencia", texto: "Transferencia" },
                          { valor: "tarjeta", texto: "Tarjeta" },
                          { valor: "otro", texto: "Otro" }
                      ] }
                ],
                alGuardar: function (v) {
                    return F.enviar("guardar_gasto.php", {
                        id_categoria: parseInt(v.id_categoria, 10),
                        descripcion: v.descripcion,
                        monto: v.monto,
                        metodo_pago: v.metodo_pago
                    }).then(function () {
                        return { titulo: "Gasto registrado", detalle: v.descripcion + " · " + dinero(v.monto) };
                    });
                }
            });
        });
    }

    /* ==================================================================
       VENTAS → catálogo de servicios
       ================================================================== */
    if (body.classList.contains("pag-ventas")) {
        const CATEGORIAS = ["corte", "barba", "combo", "premium", "complemento"];

        function formularioServicio(card) {
            const editando = !!card;
            const d = card ? card.dataset : {};
            F.modal({
                titulo: editando ? "Editar servicio" : "Nuevo servicio",
                subtitulo: editando ? String(d.id).toUpperCase() : "Se agregará al catálogo",
                textoGuardar: editando ? "Guardar cambios" : "Guardar servicio",
                campos: [
                    { name: "nombre", label: "Nombre", tipo: "text", requerido: true, maxLen: 100, valor: d.nombre || "" },
                    { name: "categoria", label: "Categoría", tipo: "select", requerido: true, valor: d.cat || "corte", ancho: 1,
                      opciones: CATEGORIAS.map(function (c) { return { valor: c, texto: mayus(c) }; }) },
                    { name: "duracion_min", label: "Duración (min)", tipo: "number", requerido: true, entero: true, min: 0, max: 600, valor: d.duracion || "", ancho: 1 },
                    { name: "precio", label: "Precio ($)", tipo: "number", requerido: true, min: 0, max: 99999.99, step: "0.01", valor: d.precio || "" },
                    { name: "descripcion", label: "Descripción", tipo: "textarea", maxLen: 500, valor: d.desc || "" }
                ],
                alGuardar: function (v) {
                    return F.enviar("guardar_servicio.php", {
                        accion: editando ? "editar" : "crear",
                        id_servicio: editando ? d.id : undefined,
                        nombre: v.nombre, categoria: v.categoria, descripcion: v.descripcion,
                        duracion_min: v.duracion_min, precio: v.precio
                    }).then(function () {
                        return { titulo: editando ? "Servicio actualizado" : "Servicio agregado", detalle: v.nombre + " · " + dinero(v.precio) };
                    });
                }
            });
        }

        const nuevo = $("[data-nuevo-servicio]");
        if (nuevo) nuevo.addEventListener("click", function () { formularioServicio(null); });

        document.addEventListener("click", function (e) {
            const btn = e.target.closest(".servicio-card .editar, .servicio-card .eliminar");
            if (!btn) return;
            const card = btn.closest(".servicio-card");
            if (btn.classList.contains("editar")) { formularioServicio(card); return; }

            if (!confirm("¿Eliminar el servicio «" + card.dataset.nombre + "»?\nDejará de aparecer en el catálogo y en Nueva venta; las ventas anteriores se conservan.")) return;
            btn.disabled = true;
            F.enviar("guardar_servicio.php", { accion: "eliminar", id_servicio: card.dataset.id }).then(function () {
                F.aviso("Servicio eliminado", card.dataset.nombre);
                setTimeout(function () { location.reload(); }, 1000);
            }).catch(function (err) {
                btn.disabled = false;
                F.aviso("No se pudo eliminar", err.message);
            });
        });
    }

    /* ==================================================================
       INVENTARIO → productos y materiales
       ================================================================== */
    if (body.classList.contains("pag-inventario")) {
        function unicos(sel, attr) {
            const out = [];
            todos(sel).forEach(function (el) {
                const v = el.dataset[attr];
                if (v && out.indexOf(v) === -1) out.push(v);
            });
            return out;
        }

        function formularioInventario(tipo, fila) {
            const editando = !!fila;
            const d = fila ? fila.dataset : {};
            const esProducto = tipo === "producto";
            const campos = esProducto ? [
                { name: "nombre", label: "Producto", tipo: "text", requerido: true, maxLen: 100, valor: d.nombre || "" },
                { name: "categoria", label: "Categoría", tipo: "text", requerido: true, maxLen: 50, valor: d.categoria || "",
                  lista: unicos('tr[data-tipo="producto"]', "categoria"), ancho: 1 },
                { name: "unidad", label: "Unidad de medida", tipo: "text", requerido: true, maxLen: 30, valor: d.unidad || "pieza",
                  lista: unicos('tr[data-tipo="producto"]', "unidad"), ancho: 1 },
                { name: "costo", label: "Costo de compra ($)", tipo: "number", requerido: true, min: 0, step: "0.01", valor: d.costo || "", ancho: 1 },
                { name: "precio", label: "Precio de venta ($)", tipo: "number", requerido: true, min: 0, step: "0.01", valor: d.precio || "", ancho: 1 },
                { name: "stock", label: "Stock actual", tipo: "number", requerido: true, entero: true, min: 0, valor: d.stock || "0", ancho: 1 },
                { name: "minimo", label: "Stock mínimo", tipo: "number", requerido: true, entero: true, min: 0, valor: d.minimo || "0", ancho: 1 }
            ] : [
                { name: "nombre", label: "Material", tipo: "text", requerido: true, maxLen: 100, valor: d.nombre || "" },
                { name: "unidad", label: "Unidad", tipo: "text", requerido: true, maxLen: 30, valor: d.unidad || "pieza",
                  lista: unicos('tr[data-tipo="material"]', "unidad"), ancho: 1 },
                { name: "costo", label: "Costo unitario ($)", tipo: "number", requerido: true, min: 0, step: "0.01", valor: d.costo || "", ancho: 1 },
                { name: "existencia", label: "Existencia", tipo: "number", requerido: true, entero: true, min: 0, valor: d.existencia || "0", ancho: 1 },
                { name: "minimo", label: "Mínimo", tipo: "number", requerido: true, entero: true, min: 0, valor: d.minimo || "0", ancho: 1 },
                { name: "servicios", label: "Se usa en", tipo: "text", maxLen: 500, valor: d.servicios || "" }
            ];

            F.modal({
                titulo: (editando ? "Editar " : "Nuevo ") + (esProducto ? "producto" : "material"),
                subtitulo: editando ? String(d.id).toUpperCase() : (esProducto ? "Producto para venta" : "Material de uso interno"),
                textoGuardar: editando ? "Guardar cambios" : "Guardar",
                campos: campos,
                alGuardar: function (v) {
                    const datos = Object.assign({ tipo: tipo, accion: editando ? "editar" : "crear" }, v);
                    if (editando) datos.id = d.id;
                    return F.enviar("guardar_inventario.php", datos).then(function () {
                        return { titulo: editando ? "Registro actualizado" : "Registro agregado", detalle: v.nombre };
                    });
                }
            });
        }

        const agregar = $("[data-agregar-inventario]");
        if (agregar) agregar.addEventListener("click", function () {
            const activa = $(".pestana.activa");
            formularioInventario(activa && activa.dataset.tabla === "materiales" ? "material" : "producto", null);
        });

        document.addEventListener("click", function (e) {
            const btn = e.target.closest('tr[data-tipo] .editar, tr[data-tipo] .eliminar');
            if (!btn) return;
            const fila = btn.closest("tr");
            const tipo = fila.dataset.tipo;
            if (btn.classList.contains("editar")) { formularioInventario(tipo, fila); return; }

            if (!confirm("¿Eliminar «" + fila.dataset.nombre + "» del inventario? Esta acción no se puede deshacer.")) return;
            btn.disabled = true;
            F.enviar("guardar_inventario.php", { tipo: tipo, accion: "eliminar", id: fila.dataset.id }).then(function () {
                F.aviso("Registro eliminado", fila.dataset.nombre);
                setTimeout(function () { location.reload(); }, 1000);
            }).catch(function (err) {
                btn.disabled = false;
                F.aviso("No se pudo eliminar", err.message);
            });
        });
    }

    /* ==================================================================
       CONFIGURACIÓN
       ================================================================== */
    if (body.classList.contains("pag-configuracion")) {
        const btn = $("[data-guardar-config]");
        const CAMPOS = [
            { name: "nombre", label: "Nombre del negocio", tipo: "text", requerido: true, maxLen: 100 },
            { name: "giro", label: "Giro", tipo: "text", requerido: true, maxLen: 150 },
            { name: "direccion", label: "Dirección", tipo: "text", requerido: true, maxLen: 500 },
            { name: "telefono", label: "Teléfono", tipo: "text", requerido: true, maxLen: 20,
              patron: /^[0-9+\-\s()]{7,20}$/, mensajePatron: "«Teléfono» solo admite números, espacios, + - ( ) (mínimo 7 dígitos)." },
            { name: "citas", label: "Atención de citas", tipo: "text", requerido: true, maxLen: 100 },
            { name: "propietario", label: "Propietario y barbero", tipo: "text", requerido: true, maxLen: 100 },
            { name: "cargo", label: "Cargo por cancelación tardía", tipo: "number", requerido: true, min: 0, max: 99999.99 }
        ];

        if (btn) btn.addEventListener("click", function () {
            const valores = {};
            CAMPOS.forEach(function (c) {
                const el = document.getElementById(c.name);
                let v = el ? el.value.trim() : "";
                if (c.name === "cargo") v = v.replace(/[$,\s]/g, "");
                valores[c.name] = v;
                if (el) el.removeAttribute("aria-invalid");
            });

            const fallo = F.validar(CAMPOS, valores);
            if (fallo) {
                const el = document.getElementById(fallo.campo);
                if (el) { el.setAttribute("aria-invalid", "true"); el.focus(); }
                F.aviso("Revisa los datos", fallo.mensaje);
                return;
            }

            btn.disabled = true;
            const original = btn.textContent;
            btn.textContent = "Guardando...";
            F.enviar("guardar_configuracion.php", valores).then(function () {
                F.aviso("Configuración guardada", "Los cambios se aplicaron correctamente");
                setTimeout(function () { location.reload(); }, 1200);
            }).catch(function (err) {
                F.aviso("No se pudo guardar", err.message);
                btn.disabled = false;
                btn.textContent = original;
            });
        });
    }
})();
