(function () {
    const contenido = document.querySelector(".app-contenido");
    if (!contenido) return;

    const paneles = Array.prototype.slice.call(contenido.querySelectorAll("[data-panel]:not(.pestana)"));
    const raices = paneles.length ? paneles : [contenido];

    function aplicar(raiz) {
        const buscar = raiz.querySelector("[data-buscar]");
        const desde = raiz.querySelector("[data-fecha-desde]");
        const hasta = raiz.querySelector("[data-fecha-hasta]");
        const lista = raiz.querySelector("select[data-columna]");
        const categoria = raiz.querySelector("select[data-categoria]");

        const texto = buscar ? buscar.value.trim().toLowerCase() : "";
        const d = desde && desde.value ? desde.value : "";
        const h = hasta && hasta.value ? hasta.value : "";
        const col = lista ? parseInt(lista.dataset.columna, 10) : -1;
        const valorLista = lista ? lista.value : "";
        const valorCategoria = categoria ? categoria.value : "";

        // Tablas
        raiz.querySelectorAll("table").forEach(function (tabla) {
            let visibles = 0;
            tabla.querySelectorAll("tbody tr:not(.sin-resultados)").forEach(function (fila) {
                let ok = true;
                if (texto && fila.textContent.toLowerCase().indexOf(texto) === -1) ok = false;
                if (ok && valorLista && fila.cells[col] && fila.cells[col].textContent.trim() !== valorLista) ok = false;
                const f = fila.dataset.fecha;
                if (ok && f && d && f < d) ok = false;
                if (ok && f && h && f > h) ok = false;
                fila.hidden = !ok;
                if (ok) visibles++;
            });

            let vacia = tabla.querySelector("tbody tr.sin-resultados");
            if (!vacia) {
                vacia = document.createElement("tr");
                vacia.className = "sin-resultados";
                vacia.innerHTML = '<td colspan="' + tabla.querySelectorAll("thead th").length + '">No se encontraron resultados</td>';
                tabla.tBodies[0].appendChild(vacia);
            }
            vacia.hidden = visibles !== 0;
            tabla.dataset.visibles = visibles;
        });

        // Tarjetas de servicios
        const tarjetas = raiz.querySelectorAll(".servicio-card");
        if (tarjetas.length) {
            let visibles = 0;
            tarjetas.forEach(function (card) {
                let ok = true;
                if (texto && card.textContent.toLowerCase().indexOf(texto) === -1) ok = false;
                if (ok && valorCategoria && card.dataset.categoria !== valorCategoria) ok = false;
                card.hidden = !ok;
                if (ok) visibles++;
            });
            const vacio = raiz.querySelector(".sin-resultados-cards");
            if (vacio) vacio.hidden = visibles !== 0;
            raiz.dataset.visiblesTarjetas = visibles;
        }

        actualizarContador(raiz);
    }

    function actualizarContador(raiz) {
        const contador = raiz.querySelector("[data-contador]");
        if (!contador) return;

        let n, unidad = ["registro", "registros"];
        const activa = Array.prototype.filter.call(raiz.querySelectorAll("table"), function (t) { return !t.hidden; })[0];
        if (activa) {
            n = parseInt(activa.dataset.visibles || "0", 10);
        } else {
            n = parseInt(raiz.dataset.visiblesTarjetas || "0", 10);
            unidad = ["servicio", "servicios"];
        }
        contador.textContent = "Mostrando " + n + " " + (n === 1 ? unidad[0] : unidad[1]);
    }

    // Pestañas
    document.querySelectorAll(".pestana").forEach(function (btn, _, todas) {
        btn.addEventListener("click", function () {
            todas.forEach(function (b) { b.classList.toggle("activa", b === btn); });

            if (btn.dataset.panel) {
                paneles.forEach(function (p) { p.hidden = p.dataset.panel !== btn.dataset.panel; });
            } else if (btn.dataset.tabla) {
                contenido.querySelectorAll("table").forEach(function (t) { t.hidden = t.id !== "tabla-" + btn.dataset.tabla; });
            }
            raices.forEach(actualizarContador);
        });
    });

    // Otros scripts (p. ej. Nueva venta) piden volver a filtrar
    document.addEventListener("pid:refiltrar", function () { raices.forEach(aplicar); });

    // Eventos de filtros, por panel
    raices.forEach(function (raiz) {
        raiz.querySelectorAll("[data-buscar], [data-fecha-desde], [data-fecha-hasta], select[data-columna], select[data-categoria]")
            .forEach(function (el) {
                el.addEventListener("input", function () { aplicar(raiz); });
                el.addEventListener("change", function () { aplicar(raiz); });
            });
        const btnFiltrar = raiz.querySelector(".btn-filtrar");
        if (btnFiltrar) btnFiltrar.addEventListener("click", function () { aplicar(raiz); });
        aplicar(raiz);
    });
})();
