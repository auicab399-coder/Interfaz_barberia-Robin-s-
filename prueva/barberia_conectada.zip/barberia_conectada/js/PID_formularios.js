/**
 * PID_formularios.js — utilidades compartidas para los formularios conectados a la base de datos:
 *   PIDForm.enviar(url, datos)   POST JSON con token CSRF; devuelve una promesa
 *   PIDForm.aviso(titulo, texto) notificación flotante
 *   PIDForm.modal(config)        ventana con formulario + validación en el navegador
 *   PIDForm.validar(campos, valores)
 * (La validación del navegador es solo comodidad: el servidor vuelve a validar todo.)
 */
(function () {
    "use strict";

    const $ = function (sel, raiz) { return (raiz || document).querySelector(sel); };

    function escapar(texto) {
        return String(texto == null ? "" : texto).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
    }

    function csrf() {
        const m = document.querySelector('meta[name="csrf-token"]');
        return m ? m.content : "";
    }

    /* ---------- Aviso flotante (reutiliza los estilos .avisos / .aviso-flotante) ---------- */
    function aviso(titulo, detalle) {
        let caja = $("#avisos");
        if (!caja) {
            caja = document.createElement("div");
            caja.id = "avisos";
            caja.className = "avisos";
            caja.setAttribute("aria-live", "polite");
            document.body.appendChild(caja);
        }
        const el = document.createElement("div");
        el.className = "aviso-flotante";
        el.innerHTML = "<strong>" + escapar(titulo) + "</strong><span>" + escapar(detalle || "") + "</span>";
        caja.appendChild(el);
        setTimeout(function () { el.classList.add("saliendo"); }, 3600);
        setTimeout(function () { el.remove(); }, 4000);
    }

    /* ---------- Envío al servidor ---------- */
    function enviar(url, datos) {
        return fetch(url, {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf() },
            body: JSON.stringify(datos)
        }).then(function (res) {
            return res.json().then(
                function (json) { return { res: res, json: json }; },
                function () { throw new Error("El servidor respondió algo inesperado. Inténtalo de nuevo."); }
            );
        }, function () {
            throw new Error("No se pudo conectar con el servidor. Revisa que Apache y MySQL estén encendidos.");
        }).then(function (r) {
            if (r.res.status === 401) {
                setTimeout(function () { window.location.replace("index.html"); }, 1500);
            }
            if (!r.json || !r.json.exito) {
                throw new Error((r.json && r.json.error) || "No se pudo guardar.");
            }
            return r.json;
        });
    }

    /* ---------- Validación en el navegador ---------- */
    function validar(campos, valores) {
        for (let i = 0; i < campos.length; i++) {
            const c = campos[i];
            const v = String(valores[c.name] == null ? "" : valores[c.name]).trim();
            if (c.requerido && v === "") return { campo: c.name, mensaje: "«" + c.label + "» es obligatorio." };
            if (v === "") continue;
            if (c.maxLen && v.length > c.maxLen) return { campo: c.name, mensaje: "«" + c.label + "» no puede pasar de " + c.maxLen + " caracteres." };
            if (c.tipo === "number") {
                const n = Number(v);
                if (!isFinite(n)) return { campo: c.name, mensaje: "«" + c.label + "» debe ser un número." };
                if (c.entero && !Number.isInteger(n)) return { campo: c.name, mensaje: "«" + c.label + "» debe ser un número entero." };
                if (c.min !== undefined && n < c.min) return { campo: c.name, mensaje: "«" + c.label + "» debe ser mayor o igual a " + c.min + "." };
                if (c.max !== undefined && n > c.max) return { campo: c.name, mensaje: "«" + c.label + "» no puede ser mayor a " + c.max + "." };
            }
            if (c.patron && !c.patron.test(v)) return { campo: c.name, mensaje: c.mensajePatron || ("«" + c.label + "» no es válido.") };
            if (c.tipo === "select" && c.opciones && !c.opciones.some(function (o) { return String(o.valor) === v; })) {
                return { campo: c.name, mensaje: "Elige una opción válida en «" + c.label + "»." };
            }
        }
        return null;
    }

    /* ---------- Ventana con formulario ---------- */
    let contador = 0;

    function campoHTML(c, id) {
        const valor = c.valor == null ? "" : c.valor;
        const req = c.requerido ? " required" : "";
        const etiqueta = '<label for="' + id + '">' + escapar(c.label) + (c.requerido ? "" : " <small>(opcional)</small>") + "</label>";
        let control;
        if (c.tipo === "select") {
            control = '<select id="' + id + '" name="' + escapar(c.name) + '"' + req + ">" +
                c.opciones.map(function (o) {
                    return '<option value="' + escapar(o.valor) + '"' + (String(o.valor) === String(valor) ? " selected" : "") + ">" + escapar(o.texto) + "</option>";
                }).join("") + "</select>";
        } else if (c.tipo === "textarea") {
            control = '<textarea id="' + id + '" name="' + escapar(c.name) + '" rows="3"' + (c.maxLen ? ' maxlength="' + c.maxLen + '"' : "") +
                (c.placeholder ? ' placeholder="' + escapar(c.placeholder) + '"' : "") + req + ">" + escapar(valor) + "</textarea>";
        } else {
            const tipo = c.tipo === "number" ? "number" : (c.tipo === "tel" ? "tel" : "text");
            control = '<input id="' + id + '" name="' + escapar(c.name) + '" type="' + tipo + '" value="' + escapar(valor) + '"' +
                (c.maxLen ? ' maxlength="' + c.maxLen + '"' : "") +
                (c.placeholder ? ' placeholder="' + escapar(c.placeholder) + '"' : "") +
                (c.tipo === "number" ? ' min="' + (c.min !== undefined ? c.min : "") + '"' + (c.max !== undefined ? ' max="' + c.max + '"' : "") +
                    ' step="' + (c.step || (c.entero ? "1" : "any")) + '" inputmode="' + (c.entero ? "numeric" : "decimal") + '"' : "") +
                (c.lista ? ' list="' + id + '_lista" autocomplete="off"' : "") + req + ">" +
                (c.lista ? '<datalist id="' + id + '_lista">' + c.lista.map(function (x) { return '<option value="' + escapar(x) + '">'; }).join("") + "</datalist>" : "");
        }
        return '<div class="form-campo">' + etiqueta + control + "</div>";
    }

    function modal(cfg) {
        const base = "pidm" + (++contador);
        const ultimoFoco = document.activeElement;

        // Agrupa en filas de dos los campos con ancho: 1
        let cuerpo = "", mitades = [];
        function vaciar() {
            if (mitades.length) { cuerpo += '<div class="form-fila">' + mitades.join("") + "</div>"; mitades = []; }
        }
        cfg.campos.forEach(function (c, i) {
            const html = campoHTML(c, base + "_" + i);
            if (c.ancho === 1) { mitades.push(html); if (mitades.length === 2) vaciar(); }
            else { vaciar(); cuerpo += html; }
        });
        vaciar();

        const fondo = document.createElement("div");
        fondo.className = "modal-fondo";
        fondo.hidden = true;
        fondo.innerHTML =
            '<div class="modal modal-chico" role="dialog" aria-modal="true" aria-labelledby="' + base + '_t">' +
            '<form novalidate>' +
                '<header class="modal-cabeza"><div><h2 id="' + base + '_t">' + escapar(cfg.titulo) + "</h2><p>" + escapar(cfg.subtitulo || "") + "</p></div>" +
                '<button type="button" class="modal-cerrar" data-cerrar aria-label="Cerrar">✕</button></header>' +
                '<div class="modal-cuerpo">' + cuerpo + '<p class="form-error" role="alert" hidden></p></div>' +
                '<footer class="modal-pie"><button type="button" class="btn-cancelar" data-cerrar>Cancelar</button>' +
                '<button type="submit" class="btn-guardar">' + escapar(cfg.textoGuardar || "Guardar") + "</button></footer>" +
            "</form></div>";
        document.body.appendChild(fondo);

        const form = $("form", fondo);
        const error = $(".form-error", fondo);
        const btnGuardar = $(".btn-guardar", fondo);

        function cerrar() {
            document.removeEventListener("keydown", alTeclear);
            fondo.classList.remove("visible");
            document.body.classList.remove("modal-abierto");
            setTimeout(function () { fondo.remove(); }, 220);
            if (ultimoFoco && ultimoFoco.focus) ultimoFoco.focus();
        }
        function alTeclear(e) { if (e.key === "Escape") cerrar(); }
        function mostrarError(msg) { error.textContent = msg; error.hidden = false; }

        function leer() {
            const valores = {};
            cfg.campos.forEach(function (c) {
                const el = form.elements[c.name];
                valores[c.name] = el ? String(el.value).trim() : "";
            });
            return valores;
        }

        form.addEventListener("input", function () {
            error.hidden = true;
            Array.prototype.forEach.call(form.querySelectorAll("[aria-invalid]"), function (el) { el.removeAttribute("aria-invalid"); });
        });

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            const valores = leer();
            const fallo = validar(cfg.campos, valores);
            if (fallo) {
                mostrarError(fallo.mensaje);
                const el = form.elements[fallo.campo];
                if (el) { el.setAttribute("aria-invalid", "true"); el.focus(); }
                return;
            }
            btnGuardar.disabled = true;
            const textoOriginal = btnGuardar.textContent;
            btnGuardar.textContent = "Guardando...";

            Promise.resolve(cfg.alGuardar(valores)).then(function (exito) {
                cerrar();
                aviso((exito && exito.titulo) || "Guardado", (exito && exito.detalle) || "");
                setTimeout(function () { location.reload(); }, 1300);   // recarga para ver el dato nuevo
            }).catch(function (err) {
                mostrarError(err && err.message ? err.message : "No se pudo guardar.");
                btnGuardar.disabled = false;
                btnGuardar.textContent = textoOriginal;
            });
        });

        fondo.addEventListener("mousedown", function (e) { if (e.target === fondo) cerrar(); });
        Array.prototype.forEach.call(fondo.querySelectorAll("[data-cerrar]"), function (b) { b.addEventListener("click", cerrar); });
        document.addEventListener("keydown", alTeclear);

        fondo.hidden = false;
        document.body.classList.add("modal-abierto");
        requestAnimationFrame(function () { fondo.classList.add("visible"); });
        setTimeout(function () {
            const primero = form.querySelector("input, select, textarea");
            if (primero) primero.focus();
        }, 60);
    }

    window.PIDForm = { enviar: enviar, aviso: aviso, modal: modal, validar: validar, escapar: escapar, csrf: csrf };
})();
