(function () {
    const PID = window.PID;
    if (!PID) return;

    const esc = PID.escapar;
    const $ = function (sel, raiz) { return (raiz || document).querySelector(sel); };

    /* ---------- Aviso (toast) ---------- */
    function aviso(titulo, detalle) {
        let caja = $("#avisos");
        if (!caja) {
            caja = document.createElement("div");
            caja.id = "avisos";
            caja.className = "avisos";
            caja.setAttribute("aria-live", "polite");
            document.body.appendChild(caja);
        }
        const el = document.createElement("div");
        el.className = "aviso-flotante";
        el.innerHTML = "<strong>" + esc(titulo) + "</strong><span>" + esc(detalle) + "</span>";
        caja.appendChild(el);
        setTimeout(function () { el.classList.add("saliendo"); }, 3600);
        setTimeout(function () { el.remove(); }, 4000);
    }
    PID.aviso = aviso;

    /* ---------- Ventana ---------- */
    let productosVenta = [];
    let ultimoFoco = null;

    const opcionesServicios = PID.SERVICIOS.map(function (s) {
        return '<label class="opcion-servicio">' +
            '<input type="checkbox" name="servicio" value="' + esc(s.id) + '">' +
            '<span class="opcion-nombre">' + esc(s.nombre) + '</span>' +
            '<span class="opcion-precio">' + PID.dinero(s.precio) + '</span></label>';
    }).join("");

    const opcionesProductos = PID.PRODUCTOS.map(function (p) {
        const conStock = typeof p.stock === "number";
        const agotado = conStock && p.stock <= 0;
        return '<option value="' + esc(p.id) + '"' + (agotado ? " disabled" : "") + '>' + esc(p.nombre) + ' · ' + PID.dinero(p.precio) +
            (conStock ? (agotado ? " (agotado)" : " (stock " + p.stock + ")") : "") + '</option>';
    }).join("");

    document.body.insertAdjacentHTML("beforeend",
        '<div class="modal-fondo" id="modalVenta" hidden>' +
        '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="mvTitulo">' +
        '<form id="formVenta" novalidate>' +
            '<header class="modal-cabeza">' +
                '<div><h2 id="mvTitulo">Nueva venta</h2><p id="mvSubtitulo"></p></div>' +
                '<button type="button" class="modal-cerrar" data-cerrar aria-label="Cerrar">✕</button>' +
            '</header>' +
            '<div class="modal-cuerpo">' +
                '<div class="form-fila">' +
                    '<div class="form-campo"><label for="mvCliente">Cliente</label>' +
                    '<input id="mvCliente" type="text" list="mvClientes" maxlength="100" placeholder="Nombre del cliente" autocomplete="off" required>' +
                    '<datalist id="mvClientes"></datalist></div>' +
                    '<div class="form-campo"><label for="mvTelefono">Teléfono <small>(opcional)</small></label>' +
                    '<input id="mvTelefono" type="tel" maxlength="20" placeholder="985 000 0000" autocomplete="off"></div>' +
                '</div>' +
                '<fieldset class="form-grupo"><legend>Servicios</legend>' +
                    '<div class="opciones-servicios">' + opcionesServicios + '</div></fieldset>' +
                '<fieldset class="form-grupo"><legend>Productos <small>(opcional)</small></legend>' +
                    '<div class="producto-agregar">' +
                        '<select id="mvProducto" aria-label="Producto">' + opcionesProductos + '</select>' +
                        '<input id="mvCantidad" type="number" min="1" max="20" value="1" aria-label="Cantidad">' +
                        '<button type="button" class="btn-secundario" id="mvAgregarProducto">Agregar</button>' +
                    '</div>' +
                    '<ul class="lista-productos" id="mvListaProductos"></ul></fieldset>' +
                '<div class="form-fila">' +
                    '<fieldset class="form-grupo"><legend>Método de pago</legend>' +
                        '<div class="segmentado">' +
                            '<label><input type="radio" name="pago" value="Efectivo" checked><span>Efectivo</span></label>' +
                            '<label><input type="radio" name="pago" value="Transferencia"><span>Transferencia</span></label>' +
                            '<label><input type="radio" name="pago" value="Tarjeta"><span>Tarjeta</span></label>' +
                        '</div></fieldset>' +
                    '<div class="form-campo"><label for="mvDescuento">Descuento <small>($)</small></label>' +
                    '<input id="mvDescuento" type="number" min="0" step="1" value="0" inputmode="decimal"></div>' +
                '</div>' +
                '<div class="resumen-venta">' +
                    '<div><span>Subtotal</span><strong id="mvSubtotal">$ 0.00</strong></div>' +
                    '<div><span>Descuento</span><strong id="mvDesc">- $ 0.00</strong></div>' +
                '</div>' +
                '<p class="form-error" id="mvError" role="alert" hidden></p>' +
            '</div>' +
            '<footer class="modal-pie">' +
                '<div class="pie-total"><span>Total a cobrar</span><strong id="mvTotal">$ 0.00</strong></div>' +
                '<button type="button" class="btn-cancelar" data-cerrar>Cancelar</button>' +
                '<button type="submit" class="btn-guardar">Registrar venta</button>' +
            '</footer>' +
        '</form></div></div>');

    const fondo = $("#modalVenta");
    const form = $("#formVenta");
    const error = $("#mvError");

    // Clientes ya registrados (sugerencias) — vienen de la tabla `clientes`
    $("#mvClientes").innerHTML = (PID.CLIENTES || []).map(function (c) {
        return '<option value="' + esc(c.nombre) + '"></option>';
    }).join("");
    $("#mvCliente").addEventListener("change", function () {
        const nombre = this.value.trim().toLowerCase();
        const conocido = (PID.CLIENTES || []).filter(function (c) { return c.nombre.toLowerCase() === nombre; })[0];
        if (conocido && conocido.telefono && !$("#mvTelefono").value) $("#mvTelefono").value = conocido.telefono;
    });

    function serviciosElegidos() {
        const ids = Array.prototype.map.call(form.querySelectorAll('input[name="servicio"]:checked'), function (i) { return i.value; });
        return PID.SERVICIOS.filter(function (s) { return ids.indexOf(s.id) !== -1; });
    }

    function calcular() {
        const sub = serviciosElegidos().reduce(function (t, s) { return t + s.precio; }, 0) +
            productosVenta.reduce(function (t, p) { return t + p.precio * p.cant; }, 0);
        const desc = Math.max(0, parseFloat($("#mvDescuento").value) || 0);
        $("#mvSubtotal").textContent = PID.dinero(sub);
        $("#mvDesc").textContent = "- " + PID.dinero(desc);
        $("#mvTotal").textContent = PID.dinero(Math.max(0, sub - desc));
        return { sub: sub, desc: desc, total: Math.max(0, sub - desc) };
    }

    function pintarProductos() {
        const lista = $("#mvListaProductos");
        lista.innerHTML = productosVenta.map(function (p, i) {
            return '<li><span>' + esc(p.nombre) + ' <b>×' + p.cant + '</b></span>' +
                '<span class="lp-precio">' + PID.dinero(p.precio * p.cant) + '</span>' +
                '<button type="button" class="eliminar" data-quitar="' + i + '" aria-label="Quitar ' + esc(p.nombre) + '">✕</button></li>';
        }).join("");
        calcular();
    }

    function mostrarError(msg) {
        error.textContent = msg;
        error.hidden = false;
    }

    function abrir() {
        ultimoFoco = document.activeElement;
        form.reset();
        productosVenta = [];
        pintarProductos();
        form.querySelectorAll(".opcion-servicio").forEach(function (l) { l.classList.remove("marcada"); });
        error.hidden = true;
        $("#mvSubtitulo").textContent = "Nuevo Registro";

        fondo.hidden = false;
        document.body.classList.add("modal-abierto");
        requestAnimationFrame(function () { fondo.classList.add("visible"); });
        setTimeout(function () { $("#mvCliente").focus(); }, 60);
    }

    function cerrar() {
        fondo.classList.remove("visible");
        document.body.classList.remove("modal-abierto");
        setTimeout(function () { fondo.hidden = true; }, 220);
        if (ultimoFoco && ultimoFoco.focus) ultimoFoco.focus();
    }

    document.querySelectorAll("[data-nueva-venta]").forEach(function (b) { b.addEventListener("click", abrir); });
    fondo.addEventListener("mousedown", function (e) { if (e.target === fondo) cerrar(); });
    fondo.querySelectorAll("[data-cerrar]").forEach(function (b) { b.addEventListener("click", cerrar); });

    form.addEventListener("change", function (e) {
        if (e.target.name === "servicio") e.target.closest(".opcion-servicio").classList.toggle("marcada", e.target.checked);
        error.hidden = true;
        calcular();
    });
    $("#mvDescuento").addEventListener("input", function () { error.hidden = true; calcular(); });

    $("#mvAgregarProducto").addEventListener("click", function () {
        const prodId = $("#mvProducto").value;
        const prod = PID.PRODUCTOS.filter(function (p) { return p.id === prodId; })[0];
        const cant = Math.min(20, Math.max(1, parseInt($("#mvCantidad").value, 10) || 1));
        if (!prod) return;
        
        const existente = productosVenta.filter(function (p) { return p.id === prod.id; })[0];
        const yaEnLista = existente ? existente.cant : 0;
        if (typeof prod.stock === "number" && yaEnLista + cant > prod.stock) {
            mostrarError("Stock insuficiente de «" + prod.nombre + "»: solo hay " + prod.stock + " disponible(s).");
            return;
        }
        if (existente) existente.cant = Math.min(20, existente.cant + cant);
        else productosVenta.push({ id: prod.id, nombre: prod.nombre, precio: prod.precio, cant: cant });
        
        $("#mvCantidad").value = 1;
        error.hidden = true;
        pintarProductos();
    });

    $("#mvListaProductos").addEventListener("click", function (e) {
        const b = e.target.closest("[data-quitar]");
        if (!b) return;
        productosVenta.splice(parseInt(b.dataset.quitar, 10), 1);
        pintarProductos();
    });

    // Envío de datos a PHP (guardar_venta.php) con token CSRF
    form.addEventListener("submit", function (e) {
        e.preventDefault();
        const cliente = $("#mvCliente").value.trim();
        const telefono = $("#mvTelefono").value.trim();
        const servicios = serviciosElegidos();
        const t = calcular();

        if (cliente.length > 100) { mostrarError("El nombre del cliente no puede pasar de 100 caracteres."); $("#mvCliente").focus(); return; }
        if (telefono && !/^[0-9+\-\s()]{7,20}$/.test(telefono)) { mostrarError("El teléfono solo admite números, espacios, + - ( ) (mínimo 7 dígitos)."); $("#mvTelefono").focus(); return; }
        if (!servicios.length && !productosVenta.length) { mostrarError("Elige al menos un servicio o un producto."); return; }
        if (t.desc > t.sub) { mostrarError("El descuento no puede ser mayor al subtotal."); $("#mvDescuento").focus(); return; }

        // El servidor vuelve a calcular precios y totales desde la base de datos;
        // aquí solo se mandan los identificadores, cantidades y el descuento.
        const datosVenta = {
            cliente: cliente,
            telefono: telefono,
            servicios: servicios.map(function (s) { return { id: s.id }; }),
            productos: productosVenta.map(function (p) { return { id: p.id, cant: p.cant }; }),
            pago: (form.querySelector('input[name="pago"]:checked') || {}).value || "Efectivo",
            descuento: t.desc
        };

        const btnGuardar = form.querySelector(".btn-guardar");
        btnGuardar.disabled = true;
        btnGuardar.textContent = "Guardando...";

        window.PIDForm.enviar("guardar_venta.php", datosVenta).then(function (data) {
            cerrar();
            aviso("Venta registrada", "Folio V-" + String(data.folio).padStart(4, "0") + " · " + (cliente || "Público General") + " · " + PID.dinero(t.total));
            setTimeout(function () { location.reload(); }, 1500);   // recarga para mostrar la venta nueva
        }).catch(function (err) {
            mostrarError(err.message);
            btnGuardar.disabled = false;
            btnGuardar.textContent = "Registrar venta";
        });
    });
})();