(function () {
    const PID = window.PID;
    if (!PID) return;

    const esc = PID.escapar;
    const $ = function (s, r) { return (r || document).querySelector(s); };
    const reducir = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];

    function suma(lista, campo) { return lista.reduce(function (t, x) { return t + x[campo]; }, 0); }
    function corto(n) { return "$" + Math.round(n).toLocaleString("en-US"); }

    function dias(desde, hasta) {
        const out = [];
        const d = new Date(desde + "T00:00:00Z"), fin = new Date(hasta + "T00:00:00Z");
        while (d <= fin) { out.push(d.toISOString().slice(0, 10)); d.setUTCDate(d.getUTCDate() + 1); }
        return out;
    }

    /* Número que "cuenta" hasta su valor */
    function animarNumero(el, hasta, formato) {
        const desde = el._valor || 0;
        el._valor = hasta;
        if (reducir || desde === hasta) { el.textContent = formato(hasta); return; }
        const inicio = performance.now(), dur = 800;
        function paso(ahora) {
            const t = Math.min(1, (ahora - inicio) / dur);
            const suave = 1 - Math.pow(1 - t, 3);
            el.textContent = formato(desde + (hasta - desde) * suave);
            if (t < 1) requestAnimationFrame(paso);
        }
        requestAnimationFrame(paso);
    }

    function pintar(nuevaFolio) {
        const ventas = PID.todasLasVentas();
        const gastos = PID.GASTOS;
        const hoy = PID.FECHA_TRABAJO, desde = PID.PERIODO_DESDE;

        const ventasHoy = ventas.filter(function (v) { return v.fecha === hoy; });
        const gastosHoy = gastos.filter(function (g) { return g.fecha === hoy; });
        const tVentasHoy = suma(ventasHoy, "total");
        const tGastosHoy = suma(gastosHoy, "monto");

        /* Tarjetas del día */
        animarNumero($('[data-m="ventas"] [data-valor]'), tVentasHoy, PID.dinero);
        $('[data-m="ventas"] [data-detalle]').textContent = ventasHoy.length + (ventasHoy.length === 1 ? " venta registrada" : " ventas registradas");
        animarNumero($('[data-m="gastos"] [data-valor]'), tGastosHoy, PID.dinero);
        animarNumero($('[data-m="ganancia"] [data-valor]'), tVentasHoy - tGastosHoy, PID.dinero);

        /* Periodo */
        const enPeriodo = ventas.filter(function (v) { return v.fecha >= desde && v.fecha <= hoy; });
        const gastosPeriodo = gastos.filter(function (g) { return g.fecha >= desde && g.fecha <= hoy; });
        const tVentas = suma(enPeriodo, "total");
        const tGastos = suma(gastosPeriodo, "monto");
        const lista = dias(desde, hoy);

        /* Ventas y gastos por día (para la lectura rápida) */
        const porDia = lista.map(function (f) {
            return {
                f: f,
                v: suma(enPeriodo.filter(function (x) { return x.fecha === f; }), "total"),
                g: suma(gastosPeriodo.filter(function (x) { return x.fecha === f; }), "monto")
            };
        });

        /* Lectura rápida */
        const conteo = {};
        enPeriodo.forEach(function (v) { v.servicios.forEach(function (s) { conteo[s] = (conteo[s] || 0) + 1; }); });
        const top = Object.keys(conteo).sort(function (a, b) { return conteo[b] - conteo[a]; })[0];
        const mejor = porDia.slice().sort(function (a, b) { return b.v - a.v; })[0];
        const ticket = enPeriodo.length ? tVentas / enPeriodo.length : 0;
        const margen = tVentas ? (tVentas - tGastos) / tVentas * 100 : 0;

        $("[data-lectura]").innerHTML =
            item("Ticket promedio", PID.dinero(ticket), enPeriodo.length + " ventas en el periodo") +
            item("Servicio más vendido", esc(top || "—"), top ? conteo[top] + (conteo[top] === 1 ? " vez" : " veces") : "Sin ventas") +
            item("Mejor día", mejor ? PID.fechaCorta(mejor.f) : "—", mejor ? PID.dinero(mejor.v) + " en ventas" : "") +
            item("Margen del periodo", margen.toFixed(1) + " %", "Ganancia " + PID.dinero(tVentas - tGastos));

        /* Últimos movimientos */
        const movs = ventas.map(function (v) {
            return { f: v.fecha, o: 1, h: v.hora, tipo: "Venta", folio: v.folio, desc: v.folio + " · " +
                v.servicios.concat(v.productos.map(function (p) { return p.nombre + " ×" + p.cant; })).join(", "), monto: v.total };
        }).concat(gastos.map(function (g) {
            return { f: g.fecha, o: 0, h: "", tipo: "Gasto", desc: g.descripcion, monto: -g.monto };
        })).sort(function (a, b) {
            if (a.f !== b.f) return a.f < b.f ? 1 : -1;   // fecha: la más reciente primero
            return b.o - a.o;                            // ese día, ventas antes que gastos (orden original se conserva)
        }).slice(0, 6);

        $("[data-movimientos]").innerHTML = movs.map(function (m) {
            const nueva = nuevaFolio && m.folio === nuevaFolio ? ' class="fila-nueva"' : "";
            return '<tr' + nueva + ' data-fecha="' + m.f + '"><td>' + PID.fechaCorta(m.f) + '</td>' +
                '<td><span class="tipo ' + m.tipo.toLowerCase() + '">' + m.tipo + '</span></td>' +
                '<td class="texto">' + esc(m.desc) + '</td>' +
                '<td class="monto"><span' + (m.monto < 0 ? ' class="negativo"' : "") + '>' +
                (m.monto < 0 ? "- " + PID.dinero(-m.monto) : PID.dinero(m.monto)) + '</span></td></tr>';
        }).join("");
    }

    function item(titulo, valor, nota) {
        return '<div class="lectura-item"><span class="lectura-titulo">' + titulo + '</span>' +
            '<strong>' + valor + '</strong><span class="lectura-nota">' + nota + '</span></div>';
    }

    /* Ticket del día: total de ventas, gastos y ganancia */
    function imprimirTicket() {
        const hoy = PID.FECHA_TRABAJO;
        const ventas = PID.todasLasVentas().filter(function (v) { return v.fecha === hoy; });
        const gastos = PID.GASTOS.filter(function (g) { return g.fecha === hoy; });
        const tV = suma(ventas, "total"), tG = suma(gastos, "monto");
        function fila(a, b) { return '<div class="t-fila"><span>' + a + '</span><span>' + b + '</span></div>'; }

        let t = document.getElementById("ticket-impresion");
        if (!t) { t = document.createElement("div"); t.id = "ticket-impresion"; document.body.appendChild(t); }
        t.innerHTML =
            '<h2>Barbería Robin\'s</h2><p class="t-centro">Cierre del día · ' + PID.fechaCorta(hoy) + '</p><hr>' +
            '<p class="t-titulo">Ventas</p>' +
            (ventas.map(function (v) { return fila(esc(v.folio) + " · " + esc(v.hora), PID.dinero(v.total)); }).join("") || '<p class="t-centro">Sin ventas</p>') +
            fila("<strong>Total ventas</strong>", "<strong>" + PID.dinero(tV) + "</strong>") + '<hr>' +
            '<p class="t-titulo">Gastos</p>' +
            (gastos.map(function (g) { return fila(esc(g.descripcion), "- " + PID.dinero(g.monto)); }).join("") || '<p class="t-centro">Sin gastos</p>') +
            fila("<strong>Total gastos</strong>", "<strong>- " + PID.dinero(tG) + "</strong>") + '<hr>' +
            '<div class="t-total">' + fila("TOTAL (ganancia)", PID.dinero(tV - tG)) + '</div>' +
            '<p class="t-centro">¡Gracias!</p>';
        window.print();
    }
    const btnTicket = $("[data-imprimir-ticket]");
    if (btnTicket) btnTicket.addEventListener("click", imprimirTicket);

    pintar();
    document.addEventListener("pid:venta", function (e) { pintar(e.detail.folio); });
})();
