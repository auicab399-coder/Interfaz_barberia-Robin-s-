-- ============================================================================
-- Migración recomendada: pasar las tablas de MyISAM a InnoDB
-- Base de datos: barberia_robins
--
-- ¿Por qué?  MyISAM NO soporta transacciones: un BEGIN / ROLLBACK no deshace nada.
-- Con InnoDB, si una venta falla a la mitad (por ejemplo, después de guardar la venta
-- pero antes de descontar el stock), MySQL revierte TODO y la base queda consistente.
--
-- Cómo ejecutarlo: abre este archivo en HeidiSQL (o en el cliente mysql) y ejecútalo.
-- Es seguro repetirlo: si una tabla ya es InnoDB, no pasa nada. No borra datos.
-- Haz un respaldo (exportar la base) antes, como con cualquier cambio de estructura.
-- ============================================================================
USE `barberia_robins`;

ALTER TABLE `categorias_gastos`       ENGINE = InnoDB;
ALTER TABLE `clientes`                ENGINE = InnoDB;
ALTER TABLE `configuracion_negocio`   ENGINE = InnoDB;
ALTER TABLE `detalle_venta_producto`  ENGINE = InnoDB;
ALTER TABLE `detalle_venta_servicio`  ENGINE = InnoDB;
ALTER TABLE `gastos`                  ENGINE = InnoDB;
ALTER TABLE `materiales_insumos`      ENGINE = InnoDB;
ALTER TABLE `productos`               ENGINE = InnoDB;
ALTER TABLE `servicios`               ENGINE = InnoDB;
ALTER TABLE `usuarios`                ENGINE = InnoDB;
ALTER TABLE `ventas`                  ENGINE = InnoDB;

-- Verificación: todas las filas deben mostrar InnoDB
SELECT TABLE_NAME, ENGINE
  FROM information_schema.TABLES
 WHERE TABLE_SCHEMA = 'barberia_robins'
 ORDER BY TABLE_NAME;
