# Barbería Robin's — interfaz conectada a MySQL

## Cómo ponerlo a funcionar
1. Copia la carpeta del proyecto a `C:\wamp64\www\` (o a `htdocs` si usas XAMPP).
2. Importa `barberia_robins.sql` (si aún no lo tienes) y **ejecuta `migracion_innodb.sql`** en HeidiSQL
   (pasa las tablas de MyISAM a InnoDB para que las transacciones y el rollback funcionen de verdad).
3. Abre `http://localhost/<carpeta>/index.html` e inicia sesión (usuario `admin`, contraseña `admin123`).
   En el primer inicio de sesión la contraseña se guarda cifrada (bcrypt) en `usuarios.password_hash`.
4. Si tu MySQL no usa `root` sin contraseña, ajusta `conexion/db.php`.

## Archivos nuevos
| Archivo | Para qué sirve |
|---|---|
| `login.php`, `logout.php` | Inicio/cierre de sesión; el usuario activo se guarda en sesión |
| `conexion/auth.php` | Sesión, token CSRF, validadores y transacciones compartidas |
| `conexion/catalogo.php` | Catálogo de servicios, productos y clientes leído de MySQL para "Nueva venta" |
| `guardar_venta.php` | Venta + detalle + descuento de stock (reescrito) |
| `guardar_gasto.php` | Nuevo gasto (`gastos`) con el `id_usuario` de la sesión |
| `guardar_servicio.php` | Agregar / editar / eliminar servicio |
| `guardar_inventario.php` | Agregar / editar / eliminar producto o material |
| `guardar_configuracion.php` | Guardar la pantalla de Configuración |
| `js/PID_formularios.js`, `js/PID_acciones.js` | Modal, validación en el navegador y conexión de botones |
| `migracion_innodb.sql` | Cambio de motor MyISAM → InnoDB |

## Qué se conectó
- **Gastos**: botón «Agregar nuevo gasto» → modal (categoría, descripción, monto, método de pago).
- **Ventas**: «Nueva venta» (ya existía, ahora validada en el servidor), «Agregar servicio», ✎ editar y ✕ eliminar servicio.
- **Inventario**: «Agregar» (según la pestaña activa), ✎ y ✕ en productos y materiales.
- **Configuración**: «Guardar cambios».

## Pendiente / no incluido
- «Cambiar logo» (Configuración) sigue sin función: requiere subir archivos y no hay columna en la BD para guardarlo.
- «Imprimir ticket» (Inicio) no escribe en la BD, no se tocó.
- La sección «Lectura rápida» de Inicio (`js/PID_inicio.js`) sigue usando datos de demostración de `PID_datos.js`.
