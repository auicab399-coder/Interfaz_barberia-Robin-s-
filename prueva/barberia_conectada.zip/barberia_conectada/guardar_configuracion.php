<?php
/**
 * Guarda la pantalla de Configuración:
 *  - configuracion_negocio (id_config = 1)
 *  - usuarios.nombre del usuario activo (propietario)
 *  - servicios.precio del cargo por cancelación tardía (s09)
 * Las tres escrituras van en una sola transacción.
 */
define('ES_API', true);
require_once __DIR__ . '/conexion/auth.php';

solo_post();
requerir_sesion();
verificar_csrf();

try {
    $d = leer_json();

    $nombre      = v_texto($d['nombre'] ?? '', 'Nombre del negocio', 100);
    $giro        = v_texto($d['giro'] ?? '', 'Giro', 150);
    $direccion   = v_texto($d['direccion'] ?? '', 'Dirección', 500);
    $telefono    = v_telefono($d['telefono'] ?? '', 'Teléfono', true);
    $citas       = v_texto($d['citas'] ?? '', 'Atención de citas', 100);
    $propietario = v_texto($d['propietario'] ?? '', 'Propietario y barbero', 100);
    $cargo       = dec(v_centavos($d['cargo'] ?? '', 'Cargo por cancelación tardía', 0, 99999.99));
    $id_usuario  = (int)$_SESSION['id_usuario'];

    en_transaccion($conexion, function () use ($conexion, $nombre, $giro, $direccion, $telefono, $citas, $propietario, $cargo, $id_usuario) {
        $q = $conexion->prepare("UPDATE configuracion_negocio SET nombre = ?, giro = ?, direccion = ?, telefono = ?, citas = ? WHERE id_config = 1");
        $q->bind_param('sssss', $nombre, $giro, $direccion, $telefono, $citas);
        $q->execute();
        $q->close();

        $q = $conexion->prepare("UPDATE usuarios SET nombre = ? WHERE id_usuario = ?");
        $q->bind_param('si', $propietario, $id_usuario);
        $q->execute();
        $q->close();

        $q = $conexion->prepare("UPDATE servicios SET precio = ? WHERE id_servicio = 's09'");
        $q->bind_param('s', $cargo);
        $q->execute();
        $q->close();
    });

    $_SESSION['nombre'] = $propietario;
    responder_json(['exito' => true]);

} catch (Throwable $e) {
    responder_excepcion($e);
}
