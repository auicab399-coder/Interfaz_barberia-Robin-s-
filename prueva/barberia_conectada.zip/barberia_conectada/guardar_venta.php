<?php
/**
 * Registra una venta: ventas + detalle_venta_servicio + detalle_venta_producto
 * y descuenta el stock de productos.
 *
 * - Todo el SQL usa sentencias preparadas.
 * - Los precios y el stock se leen de la base de datos (no se confía en lo que manda el navegador).
 * - Todo se hace en UNA transacción: si algo falla se hace rollback.
 */
define('ES_API', true);
require_once __DIR__ . '/conexion/auth.php';

solo_post();
requerir_sesion();
verificar_csrf();

$TABLAS = ['ventas', 'detalle_venta_servicio', 'detalle_venta_producto', 'productos', 'clientes'];
$folio_creado = null;      // para limpiar a mano si el motor no soporta transacciones (MyISAM)
$stock_descontado = [];    // idem
$transaccional = true;

try {
    $d = leer_json();
    $id_usuario = (int)$_SESSION['id_usuario'];

    /* ---------- 1. Validación de la entrada ---------- */
    $cliente  = v_texto($d['cliente'] ?? '', 'Cliente', 100, false);
    $telefono = v_telefono($d['telefono'] ?? '', 'Teléfono', false);
    $pago     = v_opcion($d['pago'] ?? '', 'Método de pago', ['efectivo', 'transferencia', 'tarjeta']);

    $ids_servicios = [];
    if (isset($d['servicios'])) {
        if (!is_array($d['servicios'])) { throw new ErrorValidacion('La lista de servicios no es válida.'); }
        foreach ($d['servicios'] as $s) {
            $id = v_texto(is_array($s) ? ($s['id'] ?? '') : '', 'Servicio', 10);
            $ids_servicios[strtolower($id)] = $id;           // sin duplicados
        }
    }

    $cant_productos = [];                                     // id (minúsculas) => ['id'=>, 'cant'=>]
    if (isset($d['productos'])) {
        if (!is_array($d['productos'])) { throw new ErrorValidacion('La lista de productos no es válida.'); }
        foreach ($d['productos'] as $p) {
            $id   = v_texto(is_array($p) ? ($p['id'] ?? '') : '', 'Producto', 10);
            $cant = v_entero(is_array($p) ? ($p['cant'] ?? '') : '', 'Cantidad', 1, 99);
            $k = strtolower($id);
            if (isset($cant_productos[$k])) { $cant_productos[$k]['cant'] += $cant; }
            else { $cant_productos[$k] = ['id' => $id, 'cant' => $cant]; }
        }
    }

    if (!$ids_servicios && !$cant_productos) {
        throw new ErrorValidacion('Elige al menos un servicio o un producto.');
    }
    $desc_centavos = v_centavos($d['descuento'] ?? 0, 'Descuento', 0);

    $transaccional = es_transaccional($conexion, $TABLAS);

    $folio = en_transaccion($conexion, function () use (
        $conexion, $cliente, $telefono, $pago, $ids_servicios, $cant_productos,
        $desc_centavos, $id_usuario, &$folio_creado, &$stock_descontado
    ) {
        /* ---------- 2. Precios y existencias reales (desde la BD) ---------- */
        $servicios = [];
        $q = $conexion->prepare("SELECT id_servicio, nombre, precio FROM servicios WHERE id_servicio = ? AND estado = 'activo'");
        foreach ($ids_servicios as $id) {
            $q->bind_param('s', $id);
            $q->execute();
            $f = $q->get_result()->fetch_assoc();
            if (!$f) { throw new ErrorValidacion("El servicio «$id» no existe o está inactivo."); }
            $servicios[] = ['id' => $f['id_servicio'], 'precio' => a_centavos($f['precio'])];
        }
        $q->close();

        $productos = [];
        $q = $conexion->prepare("SELECT id_producto, nombre, precio_venta, stock_actual FROM productos WHERE id_producto = ? FOR UPDATE");
        foreach ($cant_productos as $p) {
            $q->bind_param('s', $p['id']);
            $q->execute();
            $f = $q->get_result()->fetch_assoc();
            if (!$f) { throw new ErrorValidacion("El producto «{$p['id']}» no existe en el inventario."); }
            if ((int)$f['stock_actual'] < $p['cant']) {
                throw new ErrorValidacion("Stock insuficiente de «{$f['nombre']}»: disponibles {$f['stock_actual']}, solicitados {$p['cant']}.");
            }
            $productos[] = ['id' => $f['id_producto'], 'cant' => $p['cant'], 'precio' => a_centavos($f['precio_venta'])];
        }
        $q->close();

        /* ---------- 3. Totales calculados en el servidor ---------- */
        $subtotal = 0;
        foreach ($servicios as $s) { $subtotal += $s['precio']; }
        foreach ($productos as $p) { $subtotal += $p['precio'] * $p['cant']; }
        if ($desc_centavos > $subtotal) {
            throw new ErrorValidacion('El descuento no puede ser mayor al subtotal.');
        }
        $total = $subtotal - $desc_centavos;

        /* ---------- 4. Cliente (se reutiliza si ya existe) ---------- */
        $id_cliente = null;
        if ($cliente !== '') {
            $q = $conexion->prepare("SELECT id_cliente, telefono FROM clientes WHERE nombre = ? LIMIT 1");
            $q->bind_param('s', $cliente);
            $q->execute();
            $f = $q->get_result()->fetch_assoc();
            $q->close();
            if ($f) {
                $id_cliente = (int)$f['id_cliente'];
                if ($telefono !== '' && trim((string)$f['telefono']) === '') {
                    $q = $conexion->prepare("UPDATE clientes SET telefono = ? WHERE id_cliente = ?");
                    $q->bind_param('si', $telefono, $id_cliente);
                    $q->execute();
                    $q->close();
                }
            } else {
                $q = $conexion->prepare("INSERT INTO clientes (nombre, telefono) VALUES (?, ?)");
                $q->bind_param('ss', $cliente, $telefono);
                $q->execute();
                $id_cliente = (int)$conexion->insert_id;
                $q->close();
            }
        }

        /* ---------- 5. Venta ---------- */
        $sub_s = dec($subtotal); $desc_s = dec($desc_centavos); $tot_s = dec($total);
        $q = $conexion->prepare(
            "INSERT INTO ventas (id_cliente, metodo_pago, subtotal, descuento_monto, total_venta, estado, id_usuario)
             VALUES (?, ?, ?, ?, ?, 'completada', ?)"
        );
        $q->bind_param('issssi', $id_cliente, $pago, $sub_s, $desc_s, $tot_s, $id_usuario);
        $q->execute();
        $folio = (int)$conexion->insert_id;
        $folio_creado = $folio;
        $q->close();

        /* ---------- 6. Detalle de servicios ---------- */
        $q = $conexion->prepare("INSERT INTO detalle_venta_servicio (folio_venta, id_servicio, cantidad, precio_cobrado) VALUES (?, ?, 1, ?)");
        foreach ($servicios as $s) {
            $pr = dec($s['precio']);
            $q->bind_param('iss', $folio, $s['id'], $pr);
            $q->execute();
        }
        $q->close();

        /* ---------- 7. Detalle de productos + descuento de stock ---------- */
        if ($productos) {
            $ins = $conexion->prepare("INSERT INTO detalle_venta_producto (folio_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)");
            $upd = $conexion->prepare("UPDATE productos SET stock_actual = stock_actual - ? WHERE id_producto = ? AND stock_actual >= ?");
            foreach ($productos as $p) {
                $pu = dec($p['precio']);
                $st = dec($p['precio'] * $p['cant']);
                $ins->bind_param('isiss', $folio, $p['id'], $p['cant'], $pu, $st);
                $ins->execute();

                $upd->bind_param('isi', $p['cant'], $p['id'], $p['cant']);
                $upd->execute();
                if ($upd->affected_rows !== 1) {
                    throw new ErrorValidacion("Otro usuario acaba de vender «{$p['id']}» y ya no hay stock suficiente.");
                }
                $stock_descontado[] = ['id' => $p['id'], 'cant' => $p['cant']];
            }
            $ins->close();
            $upd->close();
        }

        return $folio;
    });

    responder_json(['exito' => true, 'folio' => $folio]);

} catch (Throwable $e) {
    // Si las tablas son MyISAM, el rollback no deshace nada: se limpia a mano lo ya escrito.
    if (!$transaccional && $folio_creado) {
        try {
            foreach ($stock_descontado as $s) {
                $q = $conexion->prepare("UPDATE productos SET stock_actual = stock_actual + ? WHERE id_producto = ?");
                $q->bind_param('is', $s['cant'], $s['id']);
                $q->execute();
                $q->close();
            }
            foreach (['detalle_venta_producto', 'detalle_venta_servicio', 'ventas'] as $tabla) {
                $q = $conexion->prepare("DELETE FROM $tabla WHERE folio_venta = ?");
                $q->bind_param('i', $folio_creado);
                $q->execute();
                $q->close();
            }
        } catch (Throwable $limpieza) {
            error_log('[barberia] No se pudo limpiar la venta incompleta #' . $folio_creado . ': ' . $limpieza->getMessage());
        }
    }
    responder_excepcion($e);
}
