<?php
/**
 * Alta, edición y baja de inventario.
 *   tipo   = producto (tabla `productos`) | material (tabla `materiales_insumos`)
 *   accion = crear | editar | eliminar
 */
define('ES_API', true);
require_once __DIR__ . '/conexion/auth.php';

solo_post();
requerir_sesion();
verificar_csrf();

try {
    $d      = leer_json();
    $tipo   = v_opcion($d['tipo'] ?? '', 'Tipo', ['producto', 'material']);
    $accion = v_opcion($d['accion'] ?? '', 'Acción', ['crear', 'editar', 'eliminar']);

    /* ------------------------------ ELIMINAR ------------------------------ */
    if ($accion === 'eliminar') {
        $id = v_texto($d['id'] ?? '', 'ID', 10);
        en_transaccion($conexion, function () use ($conexion, $tipo, $id) {
            if ($tipo === 'producto') {
                // No se borra un producto que ya aparece en ventas: dejaría el historial incompleto.
                $q = $conexion->prepare("SELECT 1 FROM detalle_venta_producto WHERE id_producto = ? LIMIT 1");
                $q->bind_param('s', $id);
                $q->execute();
                $usado = $q->get_result()->num_rows > 0;
                $q->close();
                if ($usado) {
                    throw new ErrorValidacion('No se puede eliminar: este producto tiene ventas registradas. Puedes dejar su stock en 0.');
                }
                $q = $conexion->prepare("DELETE FROM productos WHERE id_producto = ?");
            } else {
                $q = $conexion->prepare("DELETE FROM materiales_insumos WHERE id_material = ?");
            }
            $q->bind_param('s', $id);
            $q->execute();
            $n = $q->affected_rows;
            $q->close();
            if ($n < 1) { throw new ErrorValidacion('El registro no existe o ya fue eliminado.'); }
        });
        responder_json(['exito' => true]);
    }

    /* --------------------------- CREAR / EDITAR --------------------------- */
    $id = $accion === 'editar' ? v_texto($d['id'] ?? '', 'ID', 10) : null;

    if ($tipo === 'producto') {
        $nombre    = v_texto($d['nombre'] ?? '', 'Nombre', 100);
        $categoria = v_texto($d['categoria'] ?? '', 'Categoría', 50);
        $unidad    = v_texto($d['unidad'] ?? 'pieza', 'Unidad de medida', 30);
        $costo     = dec(v_centavos($d['costo'] ?? '', 'Costo de compra', 0, 99999999.99));
        $precio    = dec(v_centavos($d['precio'] ?? '', 'Precio de venta', 0, 99999999.99));
        $stock     = v_entero($d['stock'] ?? '', 'Stock actual', 0, 1000000);
        $minimo    = v_entero($d['minimo'] ?? '', 'Stock mínimo', 0, 1000000);

        $nuevo_id = en_transaccion($conexion, function () use ($conexion, $accion, $id, $nombre, $categoria, $unidad, $costo, $precio, $stock, $minimo) {
            if ($accion === 'crear') {
                $nid = siguiente_id($conexion, 'productos', 'id_producto', 'p');
                $q = $conexion->prepare(
                    "INSERT INTO productos (id_producto, nombre, categoria, unidad_medida, costo_compra, precio_venta, stock_actual, stock_minimo)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $q->bind_param('ssssssii', $nid, $nombre, $categoria, $unidad, $costo, $precio, $stock, $minimo);
                $q->execute();
                $q->close();
                return $nid;
            }
            $q = $conexion->prepare("SELECT 1 FROM productos WHERE id_producto = ?");
            $q->bind_param('s', $id);
            $q->execute();
            $existe = $q->get_result()->num_rows > 0;
            $q->close();
            if (!$existe) { throw new ErrorValidacion('El producto ya no existe.'); }

            $q = $conexion->prepare(
                "UPDATE productos SET nombre = ?, categoria = ?, unidad_medida = ?, costo_compra = ?, precio_venta = ?, stock_actual = ?, stock_minimo = ?
                  WHERE id_producto = ?"
            );
            $q->bind_param('sssssiis', $nombre, $categoria, $unidad, $costo, $precio, $stock, $minimo, $id);
            $q->execute();
            $q->close();
            return $id;
        });
        responder_json(['exito' => true, 'id' => $nuevo_id]);
    }

    // material
    $nombre    = v_texto($d['nombre'] ?? '', 'Nombre', 100);
    $unidad    = v_texto($d['unidad'] ?? '', 'Unidad', 30);
    $servicios = v_texto($d['servicios'] ?? '', 'Se usa en', 500, false);
    $costo     = dec(v_centavos($d['costo'] ?? '', 'Costo unitario', 0, 99999999.99));
    $existencia = v_entero($d['existencia'] ?? '', 'Existencia', 0, 1000000);
    $minimo    = v_entero($d['minimo'] ?? '', 'Mínimo', 0, 1000000);

    $nuevo_id = en_transaccion($conexion, function () use ($conexion, $accion, $id, $nombre, $unidad, $servicios, $costo, $existencia, $minimo) {
        if ($accion === 'crear') {
            $nid = siguiente_id($conexion, 'materiales_insumos', 'id_material', 'm');
            $q = $conexion->prepare(
                "INSERT INTO materiales_insumos (id_material, nombre, unidad, servicios_aplicables, costo_unitario, existencia, minimo)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $q->bind_param('sssssii', $nid, $nombre, $unidad, $servicios, $costo, $existencia, $minimo);
            $q->execute();
            $q->close();
            return $nid;
        }
        $q = $conexion->prepare("SELECT 1 FROM materiales_insumos WHERE id_material = ?");
        $q->bind_param('s', $id);
        $q->execute();
        $existe = $q->get_result()->num_rows > 0;
        $q->close();
        if (!$existe) { throw new ErrorValidacion('El material ya no existe.'); }

        $q = $conexion->prepare(
            "UPDATE materiales_insumos SET nombre = ?, unidad = ?, servicios_aplicables = ?, costo_unitario = ?, existencia = ?, minimo = ?
              WHERE id_material = ?"
        );
        $q->bind_param('ssssiis', $nombre, $unidad, $servicios, $costo, $existencia, $minimo, $id);
        $q->execute();
        $q->close();
        return $id;
    });
    responder_json(['exito' => true, 'id' => $nuevo_id]);

} catch (Throwable $e) {
    responder_excepcion($e);
}
