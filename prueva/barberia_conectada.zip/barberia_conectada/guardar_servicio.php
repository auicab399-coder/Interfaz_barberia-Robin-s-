<?php
/**
 * Alta, edición y baja de servicios (tabla `servicios`).
 *   accion = crear | editar | eliminar
 * "Eliminar" es una baja lógica (estado = 'inactivo'): así el historial de ventas
 * que ya usó ese servicio no se rompe.
 */
define('ES_API', true);
require_once __DIR__ . '/conexion/auth.php';

solo_post();
requerir_sesion();
verificar_csrf();

const CATEGORIAS_SERVICIO = ['corte', 'barba', 'combo', 'premium', 'complemento'];

try {
    $d = leer_json();
    $accion = v_opcion($d['accion'] ?? '', 'Acción', ['crear', 'editar', 'eliminar']);

    if ($accion === 'eliminar') {
        $id = v_texto($d['id_servicio'] ?? '', 'Servicio', 10);
        if (strtolower($id) === 's09') {
            throw new ErrorValidacion('El cargo por cancelación tardía no se puede eliminar; se modifica en Configuración.');
        }
        $filas = en_transaccion($conexion, function () use ($conexion, $id) {
            $q = $conexion->prepare("UPDATE servicios SET estado = 'inactivo' WHERE id_servicio = ? AND estado = 'activo'");
            $q->bind_param('s', $id);
            $q->execute();
            $n = $q->affected_rows;
            $q->close();
            return $n;
        });
        if ($filas < 1) { throw new ErrorValidacion('El servicio no existe o ya estaba eliminado.'); }
        responder_json(['exito' => true]);
    }

    // crear / editar
    $nombre      = v_texto($d['nombre'] ?? '', 'Nombre', 100);
    $categoria   = v_opcion($d['categoria'] ?? '', 'Categoría', CATEGORIAS_SERVICIO);
    $descripcion = v_texto($d['descripcion'] ?? '', 'Descripción', 500, false);
    $duracion    = v_entero($d['duracion_min'] ?? '', 'Duración (min)', 0, 600);
    $precio      = v_centavos($d['precio'] ?? '', 'Precio', 0, 99999.99);
    $precio_s    = dec($precio);

    if ($accion === 'crear') {
        $id_nuevo = en_transaccion($conexion, function () use ($conexion, $nombre, $categoria, $descripcion, $duracion, $precio_s) {
            // Nombre repetido entre servicios activos
            $q = $conexion->prepare("SELECT 1 FROM servicios WHERE nombre = ? AND estado = 'activo' LIMIT 1");
            $q->bind_param('s', $nombre);
            $q->execute();
            $repetido = $q->get_result()->num_rows > 0;
            $q->close();
            if ($repetido) { throw new ErrorValidacion('Ya existe un servicio activo con ese nombre.'); }

            $id = siguiente_id($conexion, 'servicios', 'id_servicio', 's');
            $q = $conexion->prepare(
                "INSERT INTO servicios (id_servicio, nombre, categoria, descripcion, duracion_min, precio, estado)
                 VALUES (?, ?, ?, ?, ?, ?, 'activo')"
            );
            $q->bind_param('ssssis', $id, $nombre, $categoria, $descripcion, $duracion, $precio_s);
            $q->execute();
            $q->close();
            return $id;
        });
        responder_json(['exito' => true, 'id_servicio' => $id_nuevo]);
    }

    // editar
    $id = v_texto($d['id_servicio'] ?? '', 'Servicio', 10);
    en_transaccion($conexion, function () use ($conexion, $id, $nombre, $categoria, $descripcion, $duracion, $precio_s) {
        $q = $conexion->prepare("SELECT 1 FROM servicios WHERE id_servicio = ? AND estado = 'activo'");
        $q->bind_param('s', $id);
        $q->execute();
        $existe = $q->get_result()->num_rows > 0;
        $q->close();
        if (!$existe) { throw new ErrorValidacion('El servicio ya no existe.'); }

        $q = $conexion->prepare("SELECT 1 FROM servicios WHERE nombre = ? AND estado = 'activo' AND id_servicio <> ? LIMIT 1");
        $q->bind_param('ss', $nombre, $id);
        $q->execute();
        $repetido = $q->get_result()->num_rows > 0;
        $q->close();
        if ($repetido) { throw new ErrorValidacion('Ya existe otro servicio activo con ese nombre.'); }

        $q = $conexion->prepare(
            "UPDATE servicios SET nombre = ?, categoria = ?, descripcion = ?, duracion_min = ?, precio = ? WHERE id_servicio = ?"
        );
        $q->bind_param('sssiss', $nombre, $categoria, $descripcion, $duracion, $precio_s, $id);
        $q->execute();
        $q->close();
    });
    responder_json(['exito' => true]);

} catch (Throwable $e) {
    responder_excepcion($e);
}
