<?php
require_once __DIR__ . '/conexion/auth.php';
requerir_sesion();

// 1. Obtener los datos del propietario para el encabezado
// Usuario activo (viene de la sesión iniciada en login.php)
$datos_usuario = usuario_actual();

// Categorías para el formulario "Agregar nuevo gasto" y para el filtro
$categorias = $conexion->query("SELECT id_categoria, nombre_categoria FROM categorias_gastos ORDER BY id_categoria")->fetch_all(MYSQLI_ASSOC);
$categorias_js = [];
foreach ($categorias as $c) {
    $categorias_js[] = ['id' => (int)$c['id_categoria'], 'nombre' => ucfirst_mb($c['nombre_categoria'])];
}

// 2. Obtener el historial de gastos uniendo la tabla gastos con categorias_gastos
$sql_gastos = "SELECT g.id_gasto, g.fecha_hora, cg.nombre_categoria, g.descripcion, g.monto 
               FROM gastos g 
               INNER JOIN categorias_gastos cg ON g.id_categoria = cg.id_categoria
               ORDER BY g.fecha_hora DESC";
$resultado_gastos = $conexion->query($sql_gastos);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= htmlspecialchars(csrf_token()) ?>">
    <title>Gastos · Barbería Robin's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
</head>
<body class="pag-gastos">

    <div class="app">

        <div id="menu-root"></div>

        <main class="app-contenido">

            <header class="encabezado">
                <div class="titulo">
                    <h1>Gastos</h1>
                    <p>Registro y consulta de gastos</p>
                </div>
                <div class="encabezado-derecha">
                    <button class="btn-agregar" type="button" data-nuevo-gasto><span aria-hidden="true">＋</span> Agregar nuevo gasto</button>
                    <div class="usuario">
                        <span class="usuario-icono"><?= htmlspecialchars(iniciales($datos_usuario['nombre'])) ?></span>
                        <div class="usuario-datos">
                            <strong><?= htmlspecialchars($datos_usuario['nombre']) ?></strong>
                            <small>Propietario</small>
                        </div>
                    </div>
                </div>
            </header>

            <section class="herramientas">
                <div class="buscador">
                    <span class="lupa" aria-hidden="true">⌕</span>
                    <input type="text" placeholder="Buscar descripción..." aria-label="Buscar descripción..." data-buscar>
                </div>
                <div class="filtro-select">
                    <select data-columna="2" aria-label="Categoría">
                        <option value="">Todas las categorías</option>
                        <?php foreach ($categorias_js as $cat) { ?>
                        <option><?= htmlspecialchars($cat['nombre']) ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="filtro-fechas">
                    <input type="date" value="<?= date('Y-m-d') ?>" data-fecha-desde aria-label="Fecha inicial">
                    <span aria-hidden="true">-</span>
                    <input type="date" value="<?= date('Y-m-d') ?>" data-fecha-hasta aria-label="Fecha final">
                </div>
                <button class="btn-filtrar" type="button">⌕ Filtrar</button>
            </section>

            <section class="tabla-contenedor">
                <table id="tabla-gastos">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Descripción</th>
                            <th>Categoría</th>
                            <th class="monto">Monto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($fila = $resultado_gastos->fetch_assoc()) { 
                            // Formatear la fecha para que se adapte al atributo data-fecha (Y-m-d) y a la vista (d/m/Y)
                            $fecha_unix = strtotime($fila['fecha_hora']);
                            $fecha_filtro = date('Y-m-d', $fecha_unix);
                            $fecha_visible = date('d/m/Y', $fecha_unix);
                        ?>
                        <tr data-fecha="<?= $fecha_filtro ?>">
                            <td><?= $fecha_visible ?></td>
                            <td class="texto"><?= htmlspecialchars($fila['descripcion']) ?></td>
                            <td><?= htmlspecialchars(ucfirst_mb($fila['nombre_categoria'])) ?></td>
                            <td class="monto">$ <?= htmlspecialchars(number_format($fila['monto'], 2)) ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>

                <div class="pie-tabla">
                    <p data-contador></p>
                </div>
            </section>

        </main>

    </div>

    <!-- Script del menú (Verifica que en este JS los enlaces apunten a .php) -->
    <script>window.PID_CATEGORIAS_GASTO = <?= json_encode($categorias_js, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;</script>
    <script src="js/PID_menu_d.js"></script>
    <script src="js/PID_formularios.js"></script>
    <script src="js/PID_tablas.js"></script>
    <script src="js/PID_acciones.js"></script>
</body>
</html>
