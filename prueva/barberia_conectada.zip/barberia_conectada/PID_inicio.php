<?php
require_once __DIR__ . '/conexion/auth.php';
require_once __DIR__ . '/conexion/catalogo.php';
requerir_sesion();

// 1. Obtener los datos del propietario
// Usuario activo (viene de la sesión iniciada en login.php)
$datos_usuario = usuario_actual();

// 2. Calcular las Ventas del día actual
$sql_ventas_dia = "SELECT COUNT(*) as num_ventas, COALESCE(SUM(total_venta), 0) as total_ventas 
                   FROM ventas 
                   WHERE estado = 'completada' AND DATE(fecha_hora) = CURDATE()";
$datos_ventas = $conexion->query($sql_ventas_dia)->fetch_assoc();
$total_ventas_dia = $datos_ventas['total_ventas'];
$num_ventas_dia = $datos_ventas['num_ventas'];

// 3. Calcular los Gastos del día actual
$sql_gastos_dia = "SELECT COALESCE(SUM(monto), 0) as total_gastos 
                   FROM gastos 
                   WHERE DATE(fecha_hora) = CURDATE()";
$total_gastos_dia = $conexion->query($sql_gastos_dia)->fetch_assoc()['total_gastos'];

// 4. Calcular Ganancia estimada del día
$ganancia_dia = $total_ventas_dia - $total_gastos_dia;

// 5. Contar productos y materiales que están en stock crítico (por agotarse)
$sql_stock = "
    SELECT 
        (SELECT COUNT(*) FROM productos WHERE stock_actual <= stock_minimo) +
        (SELECT COUNT(*) FROM materiales_insumos WHERE existencia <= minimo) 
    AS alertas";
$alertas_stock = $conexion->query($sql_stock)->fetch_assoc()['alertas'];

// 6. Obtener los últimos 5 movimientos generales (Ventas y Gastos recientes sin importar la fecha)
$sql_movimientos = "
    SELECT fecha_hora, 'Venta' AS tipo, CONCAT('Venta Folio V-', LPAD(folio_venta, 4, '0')) AS descripcion, total_venta AS monto 
    FROM ventas WHERE estado = 'completada'
    UNION ALL 
    SELECT fecha_hora, 'Gasto' AS tipo, descripcion, monto 
    FROM gastos
    ORDER BY fecha_hora DESC
    LIMIT 5";
$resultado_movimientos = $conexion->query($sql_movimientos);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= htmlspecialchars(csrf_token()) ?>">
    <title>Inicio · Barbería Robin's</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="PID_CSS/PID_estilos.css">
</head>
<body class="pag-inicio">

    <div class="app">

        <div id="menu-root"></div>

        <main class="app-contenido">

            <header class="encabezado">
                <div class="titulo">
                    <h1>Inicio</h1>
                    <!-- Muestra la fecha dinámica del sistema -->
                    <p>Resumen del día · <?= date('d/m/Y') ?></p>
                </div>
                <div class="encabezado-derecha">
                    <button class="btn-imprimir-ticket" type="button" data-imprimir-ticket>Imprimir ticket</button>
                    <button class="btn-agregar btn-nueva-venta" type="button" data-nueva-venta><span aria-hidden="true">＋</span> Nueva venta</button>
                    <div class="usuario">
                        <span class="usuario-icono"><?= htmlspecialchars(iniciales($datos_usuario['nombre'])) ?></span>
                        <div class="usuario-datos">
                            <strong><?= htmlspecialchars($datos_usuario['nombre']) ?></strong>
                            <small>Propietario</small>
                        </div>
                    </div>
                </div>
            </header>

            <section class="resumen">
                <article class="tarjeta ventas" data-m="ventas" tabindex="0" role="button" aria-pressed="false">
                    <div class="informacion">
                        <p>Total de ventas del día</p>
                        <h2 data-valor>$ <?= number_format($total_ventas_dia, 2) ?></h2>
                        <span class="detalle" data-detalle><?= $num_ventas_dia ?> ventas registradas hoy</span>
                    </div>
                </article>
                <article class="tarjeta gastos" data-m="gastos" tabindex="0" role="button" aria-pressed="false">
                    <div class="informacion">
                        <p>Total de gastos del día</p>
                        <h2 data-valor>$ <?= number_format($total_gastos_dia, 2) ?></h2>
                        <span class="detalle">Gastos contabilizados hoy</span>
                    </div>
                </article>
                <article class="tarjeta ganancia" data-m="ganancia" tabindex="0" role="button" aria-pressed="false">
                    <div class="informacion">
                        <p>Ganancia estimada (Hoy)</p>
                        <h2 data-valor>$ <?= number_format($ganancia_dia, 2) ?></h2>
                        <span class="detalle">Ventas menos gastos del día</span>
                    </div>
                </article>
                <article class="tarjeta inventario" data-m="inventario" tabindex="0" role="button" aria-pressed="false">
                    <div class="informacion">
                        <p>Productos por agotarse</p>
                        <h2><?= $alertas_stock ?></h2>
                        <span class="detalle">
                            <?= $alertas_stock == 0 ? "Todos con existencia suficiente" : "Requieren revisión urgente" ?>
                        </span>
                    </div>
                </article>
            </section>

            <section class="lectura" data-lectura aria-label="Lectura rápida del periodo"></section>

            <section class="bloque">
                <div class="bloque-cabeza">
                    <h2>Últimos 5 movimientos</h2>
                    <!-- Actualizamos el enlace para apuntar al archivo PHP -->
                    <a class="enlace-bloque" href="PID_ventas.php">Ver ventas</a>
                </div>
                <div class="tabla-contenedor">
                    <table>
                        <thead>
                            <tr><th>Fecha</th><th>Tipo</th><th>Descripción</th><th class="monto">Monto</th></tr>
                        </thead>
                        <tbody>
                            <?php while ($fila_mov = $resultado_movimientos->fetch_assoc()) { 
                                $fecha_unix = strtotime($fila_mov['fecha_hora']);
                                $es_gasto = ($fila_mov['tipo'] == 'Gasto');
                                $clase_monto = $es_gasto ? 'negativo' : '';
                            ?>
                            <tr>
                                <td><?= date('d/m/Y', $fecha_unix) ?></td>
                                <td><?= htmlspecialchars($fila_mov['tipo']) ?></td>
                                <td class="texto"><?= htmlspecialchars($fila_mov['descripcion']) ?></td>
                                <td class="monto"><span class="<?= $clase_monto ?>">$ <?= number_format($fila_mov['monto'], 2) ?></span></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>

    </div>

    <!-- Script del menú y otros scripts visuales -->
    <script src="js/PID_menu_d.js"></script>
    <?php imprimir_catalogo_js($conexion); ?>
    <script src="js/PID_formularios.js"></script>
    <script src="js/PID_datos.js"></script>
    <script src="js/PID_nueva_venta.js"></script>
    <script src="js/PID_inicio.js"></script>
    <script src="js/PID_tarjetas.js"></script>
</body>
</html>