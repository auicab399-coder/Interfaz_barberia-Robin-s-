<?php
/**
 * Sesión, protección CSRF y utilidades compartidas por los endpoints.
 * Uso en páginas:      require_once __DIR__ . '/conexion/auth.php'; requerir_sesion();
 * Uso en endpoints:    define('ES_API', true); require_once __DIR__ . '/conexion/auth.php';
 */
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/** Error cuyo mensaje SÍ se puede mostrar al usuario (validaciones de negocio). */
class ErrorValidacion extends Exception {}

/* ------------------------------------------------------------------ */
/*  Respuestas                                                         */
/* ------------------------------------------------------------------ */
function responder_json(array $datos, int $codigo = 200): void
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Convierte cualquier excepción en una respuesta JSON segura. */
function responder_excepcion(Throwable $e): void
{
    if ($e instanceof ErrorValidacion) {
        responder_json(['exito' => false, 'error' => $e->getMessage()], 422);
    }
    error_log('[barberia] ' . get_class($e) . ': ' . $e->getMessage() . ' en ' . $e->getFile() . ':' . $e->getLine());
    responder_json(['exito' => false, 'error' => 'Ocurrió un error al guardar en la base de datos. Inténtalo de nuevo.'], 500);
}

/* ------------------------------------------------------------------ */
/*  Sesión                                                             */
/* ------------------------------------------------------------------ */
function requerir_sesion(): void
{
    if (empty($_SESSION['id_usuario'])) {
        if (defined('ES_API')) {
            responder_json(['exito' => false, 'error' => 'Tu sesión expiró. Vuelve a iniciar sesión.', 'sesion' => false], 401);
        }
        header('Location: index.html');
        exit;
    }
}

/** Datos del usuario activo (guardados en sesión al iniciar sesión). */
function usuario_actual(): array
{
    return [
        'id_usuario'     => (int)($_SESSION['id_usuario'] ?? 0),
        'nombre'         => $_SESSION['nombre'] ?? '',
        'nombre_usuario' => $_SESSION['nombre_usuario'] ?? '',
        'rol'            => $_SESSION['rol'] ?? '',
    ];
}

function iniciales(string $nombre): string
{
    $partes = preg_split('/\s+/', trim($nombre));
    $ini = '';
    foreach ($partes as $p) {
        if ($p !== '') { $ini .= mb_strtoupper(mb_substr($p, 0, 1)); }
        if (mb_strlen($ini) >= 2) { break; }
    }
    return $ini !== '' ? $ini : '?';
}

function ucfirst_mb(string $t): string
{
    return mb_strtoupper(mb_substr($t, 0, 1)) . mb_substr($t, 1);
}

/* ------------------------------------------------------------------ */
/*  CSRF                                                               */
/* ------------------------------------------------------------------ */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verificar_csrf(): void
{
    $enviado = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $enviado)) {
        responder_json(['exito' => false, 'error' => 'Solicitud no válida. Recarga la página e inténtalo de nuevo.'], 403);
    }
}

function solo_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        header('Allow: POST');
        responder_json(['exito' => false, 'error' => 'Método no permitido.'], 405);
    }
}

function leer_json(): array
{
    $crudo = file_get_contents('php://input');
    $datos = json_decode($crudo, true);
    if (!is_array($datos)) {
        throw new ErrorValidacion('No se recibieron datos válidos.');
    }
    return $datos;
}

/* ------------------------------------------------------------------ */
/*  Validadores (lanzan ErrorValidacion con mensajes claros)           */
/* ------------------------------------------------------------------ */
function v_texto($valor, string $etiqueta, int $max, bool $requerido = true): string
{
    if (is_array($valor) || is_object($valor)) {
        throw new ErrorValidacion("El campo «$etiqueta» no es válido.");
    }
    $t = trim((string)$valor);
    $t = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $t); // quita caracteres de control
    if ($t === '' && $requerido) {
        throw new ErrorValidacion("El campo «$etiqueta» es obligatorio.");
    }
    if (mb_strlen($t) > $max) {
        throw new ErrorValidacion("El campo «$etiqueta» no puede pasar de $max caracteres.");
    }
    return $t;
}

/** Devuelve el monto en CENTAVOS (entero) para evitar errores de punto flotante. */
function v_centavos($valor, string $etiqueta, float $min = 0.0, float $max = 99999999.99): int
{
    if (is_string($valor)) { $valor = str_replace(',', '', trim($valor)); }
    if ($valor === '' || $valor === null || !is_numeric($valor)) {
        throw new ErrorValidacion("El campo «$etiqueta» debe ser un número.");
    }
    $n = (float)$valor;
    if (!is_finite($n) || $n < $min) {
        throw new ErrorValidacion("El campo «$etiqueta» debe ser mayor o igual a " . number_format($min, 2) . ".");
    }
    if ($n > $max) {
        throw new ErrorValidacion("El campo «$etiqueta» excede el máximo permitido.");
    }
    return (int)round($n * 100);
}

function v_entero($valor, string $etiqueta, int $min = 0, int $max = 1000000): int
{
    if (is_string($valor)) { $valor = trim($valor); }
    if ($valor === '' || $valor === null || filter_var($valor, FILTER_VALIDATE_INT) === false) {
        throw new ErrorValidacion("El campo «$etiqueta» debe ser un número entero.");
    }
    $n = (int)$valor;
    if ($n < $min || $n > $max) {
        throw new ErrorValidacion("El campo «$etiqueta» debe estar entre $min y $max.");
    }
    return $n;
}

function v_opcion($valor, string $etiqueta, array $permitidos): string
{
    $t = strtolower(trim((string)$valor));
    if (!in_array($t, $permitidos, true)) {
        throw new ErrorValidacion("El valor de «$etiqueta» no es válido.");
    }
    return $t;
}

function v_telefono($valor, string $etiqueta = 'Teléfono', bool $requerido = false): string
{
    $t = v_texto($valor, $etiqueta, 20, $requerido);
    if ($t !== '' && !preg_match('/^[0-9+\-\s()]{7,20}$/', $t)) {
        throw new ErrorValidacion("El campo «$etiqueta» solo admite números, espacios, + - ( ) (mínimo 7 dígitos).");
    }
    return $t;
}

/** Centavos (int) -> texto decimal "123.45" listo para bind_param("s"). */
function dec(int $centavos): string
{
    return number_format($centavos / 100, 2, '.', '');
}

/** "123.45" (DECIMAL de MySQL) -> centavos. */
function a_centavos($decimal): int
{
    return (int)round(((float)$decimal) * 100);
}

/* ------------------------------------------------------------------ */
/*  Transacciones                                                      */
/* ------------------------------------------------------------------ */
/** true si TODAS las tablas indicadas usan un motor con transacciones (InnoDB). */
function es_transaccional(mysqli $c, array $tablas): bool
{
    $ph = implode(',', array_fill(0, count($tablas), '?'));
    $stmt = $c->prepare("SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ($ph)");
    $stmt->bind_param(str_repeat('s', count($tablas)), ...$tablas);
    $stmt->execute();
    $res = $stmt->get_result();
    $ok = true;
    $vistas = 0;
    while ($f = $res->fetch_assoc()) {
        $vistas++;
        if (strcasecmp((string)$f['ENGINE'], 'InnoDB') !== 0) { $ok = false; }
    }
    $stmt->close();
    return $ok && $vistas === count($tablas);
}

/** Ejecuta $fn dentro de una transacción; si algo falla hace rollback y relanza el error. */
function en_transaccion(mysqli $c, callable $fn)
{
    $c->begin_transaction();
    try {
        $r = $fn();
        $c->commit();
        return $r;
    } catch (Throwable $e) {
        try { $c->rollback(); } catch (Throwable $ignorar) {}
        throw $e;
    }
}

/** Siguiente ID tipo 'p10', 's10', 'm11' (prefijo + número de 2 dígitos). Llamar dentro de una transacción. */
function siguiente_id(mysqli $c, string $tabla, string $columna, string $prefijo): string
{
    // $tabla y $columna son constantes internas (nunca vienen del usuario).
    $res = $c->query("SELECT COALESCE(MAX(CAST(SUBSTRING($columna, 2) AS UNSIGNED)), 0) AS m FROM $tabla FOR UPDATE");
    $max = (int)$res->fetch_assoc()['m'];
    return $prefijo . str_pad((string)($max + 1), 2, '0', STR_PAD_LEFT);
}
