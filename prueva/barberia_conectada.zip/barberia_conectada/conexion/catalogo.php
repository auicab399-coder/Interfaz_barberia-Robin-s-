<?php
/**
 * Catálogo para el formulario "Nueva venta", leído de la base de datos.
 * Sustituye a las listas fijas de js/PID_datos.js (que incluían productos P10-P12 que no existen en la BD).
 */
require_once __DIR__ . '/auth.php';

function catalogo_venta(mysqli $c): array
{
    $servicios = [];
    $r = $c->query("SELECT id_servicio, nombre, precio FROM servicios WHERE estado = 'activo' AND id_servicio <> 's09' ORDER BY id_servicio");
    while ($f = $r->fetch_assoc()) {
        $servicios[] = ['id' => $f['id_servicio'], 'nombre' => ucfirst_mb($f['nombre']), 'precio' => (float)$f['precio']];
    }

    $productos = [];
    $r = $c->query("SELECT id_producto, nombre, precio_venta, stock_actual FROM productos ORDER BY id_producto");
    while ($f = $r->fetch_assoc()) {
        $productos[] = ['id' => $f['id_producto'], 'nombre' => ucfirst_mb($f['nombre']), 'precio' => (float)$f['precio_venta'], 'stock' => (int)$f['stock_actual']];
    }

    $clientes = [];
    $r = $c->query("SELECT nombre, telefono FROM clientes ORDER BY nombre");
    while ($f = $r->fetch_assoc()) {
        $clientes[] = ['nombre' => $f['nombre'], 'telefono' => (string)$f['telefono']];
    }

    return ['servicios' => $servicios, 'productos' => $productos, 'clientes' => $clientes];
}

/** Imprime <script>window.PID_CATALOGO = {...}</script> con escape seguro para HTML. */
function imprimir_catalogo_js(mysqli $c): void
{
    $flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE;
    echo '<script>window.PID_CATALOGO = ' . json_encode(catalogo_venta($c), $flags) . ';</script>' . "\n";
}
