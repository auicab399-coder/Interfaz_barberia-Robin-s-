<?php
/**
 * Conexión a MySQL (mysqli).
 * - Los errores de MySQL se lanzan como excepciones (mysqli_sql_exception),
 *   así cada archivo puede capturarlos con try/catch.
 * - Variable principal: $conexion  (alias: $conn)
 */
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$servidor = "localhost";
$usuario  = "root";
$password = "";
$bd       = "barberia_robins";

try {
    $conexion = new mysqli($servidor, $usuario, $password, $bd);
    $conexion->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    // El detalle técnico va al log del servidor, no a la pantalla del usuario.
    error_log("[barberia] Error de conexión: " . $e->getMessage());
    http_response_code(500);
    if (defined('ES_API')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['exito' => false, 'error' => 'No se pudo conectar con la base de datos.']);
    } else {
        echo 'No se pudo conectar con la base de datos. Verifica que MySQL esté encendido.';
    }
    exit;
}

$conn = $conexion; // alias
