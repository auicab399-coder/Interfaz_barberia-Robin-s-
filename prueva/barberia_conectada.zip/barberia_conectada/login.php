<?php
require_once __DIR__ . '/conexion/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Location: index.html');
    exit;
}

$usuario  = trim((string)($_POST['usuario'] ?? ''));
$password = (string)($_POST['password'] ?? '');

if ($usuario === '' || $password === '' || mb_strlen($usuario) > 50 || strlen($password) > 200) {
    header('Location: index.html?error=1');
    exit;
}

try {
    $stmt = $conexion->prepare(
        "SELECT id_usuario, nombre, nombre_usuario, password_hash, rol, activo
           FROM usuarios WHERE nombre_usuario = ? LIMIT 1"
    );
    $stmt->bind_param('s', $usuario);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $valido = false;
    $actualizar_hash = false;

    if ($fila && (int)$fila['activo'] === 1) {
        $guardado = (string)$fila['password_hash'];
        if (password_verify($password, $guardado)) {
            $valido = true;
            $actualizar_hash = password_needs_rehash($guardado, PASSWORD_DEFAULT);
        } elseif (hash_equals($guardado, $password)) {
            // La base de datos original guarda la contraseña en texto plano ("admin123").
            // Se acepta una sola vez y se convierte a un hash seguro (bcrypt).
            $valido = true;
            $actualizar_hash = true;
        }
    }

    if (!$valido) {
        header('Location: index.html?error=1');
        exit;
    }

    if ($actualizar_hash) {
        $nuevo = password_hash($password, PASSWORD_DEFAULT);
        $upd = $conexion->prepare("UPDATE usuarios SET password_hash = ? WHERE id_usuario = ?");
        $upd->bind_param('si', $nuevo, $fila['id_usuario']);
        $upd->execute();
        $upd->close();
    }

    session_regenerate_id(true);
    $_SESSION['id_usuario']     = (int)$fila['id_usuario'];
    $_SESSION['nombre']         = $fila['nombre'];
    $_SESSION['nombre_usuario'] = $fila['nombre_usuario'];
    $_SESSION['rol']            = $fila['rol'];
    unset($_SESSION['csrf']);
    csrf_token();

    header('Location: PID_inicio.php');
    exit;

} catch (Throwable $e) {
    error_log('[barberia] login: ' . $e->getMessage());
    header('Location: index.html?error=2');
    exit;
}
