<?php
/**
 * Registra un nuevo gasto en la tabla `gastos`.
 * El id_usuario se toma de la SESIÓN (usuario activo), nunca del navegador.
 */
define('ES_API', true);
require_once __DIR__ . '/conexion/auth.php';

solo_post();
requerir_sesion();
verificar_csrf();

try {
    $d = leer_json();

    $id_categoria = v_entero($d['id_categoria'] ?? '', 'Categoría', 1, 2147483647);
    $descripcion  = v_texto($d['descripcion'] ?? '', 'Descripción', 255);
    $monto        = v_centavos($d['monto'] ?? '', 'Monto', 0.01);
    $metodo_pago  = v_opcion($d['metodo_pago'] ?? '', 'Método de pago', ['efectivo', 'transferencia', 'tarjeta', 'otro']);
    $id_usuario   = (int)$_SESSION['id_usuario'];

    $id_gasto = en_transaccion($conexion, function () use ($conexion, $id_categoria, $descripcion, $monto, $metodo_pago, $id_usuario) {
        // La categoría debe existir
        $q = $conexion->prepare("SELECT id_categoria FROM categorias_gastos WHERE id_categoria = ?");
        $q->bind_param('i', $id_categoria);
        $q->execute();
        $existe = $q->get_result()->num_rows > 0;
        $q->close();
        if (!$existe) { throw new ErrorValidacion('La categoría seleccionada no existe.'); }

        $monto_s = dec($monto);
        $q = $conexion->prepare("INSERT INTO gastos (id_categoria, descripcion, monto, metodo_pago, id_usuario) VALUES (?, ?, ?, ?, ?)");
        $q->bind_param('isssi', $id_categoria, $descripcion, $monto_s, $metodo_pago, $id_usuario);
        $q->execute();
        $nuevo = (int)$conexion->insert_id;
        $q->close();
        return $nuevo;
    });

    responder_json(['exito' => true, 'id_gasto' => $id_gasto]);

} catch (Throwable $e) {
    responder_excepcion($e);
}
